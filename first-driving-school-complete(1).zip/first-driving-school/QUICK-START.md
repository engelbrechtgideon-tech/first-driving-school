# Quick start - test it free on your computer (5 minutes)

No database, no hosting account and no card needed for this step.

## 1. Install Node.js (once)

Download the **LTS** version from https://nodejs.org and install it.
Check it worked - open Terminal (Mac) or Command Prompt (Windows):

```bash
node --version
```

You need version **20.12 or newer** (22 recommended).

## 2. Unzip and open the folder

```bash
cd path/to/first-driving-school
```

## 3. Install and start

```bash
npm install
cp .env.example .env        # Windows: copy .env.example .env
npm start
```

Open `.env` in a text editor first if you want your own staff login:

```
ADMIN_EMAIL=you@example.com
ADMIN_PASSWORD=choose-a-password
```

If you leave `ADMIN_PASSWORD` empty, the terminal prints a test login
(`admin@...` / `change-me-now`) - only on your own computer, never in production.

You will see:

```
First Driving School is running
  Booking website : http://localhost:3000/
  Staff dashboard : http://localhost:3000/staff.html
```

## 4. Try it

1. Open **http://localhost:3000** and make a booking (Code B > Single lesson > a time > your details > Confirm).
2. Open **http://localhost:3000/staff.html**, log in, press **Next 30 days** - your booking is there.
3. Tap the booking to confirm it, reschedule it, or cancel it.

Test bookings are saved in `data/dev-db.json`. Delete that file to start fresh.

## 5. Run the automatic checks (optional)

```bash
npm test
```

Expected: `Project check passed` and `All 35 checks passed.`

## 6. Look at it on your iPhone (same Wi-Fi)

1. Find your computer's local address:
   - Windows: `ipconfig` > "IPv4 Address", e.g. `192.168.1.20`
   - Mac: System Settings > Wi-Fi > Details > IP address
2. On the iPhone, open Safari: `http://192.168.1.20:3000`
3. Windows may ask to allow Node.js through the firewall - allow it on private networks.

You can book from the phone this way. **To install it as an app with offline
support you need HTTPS**, so do the free online test in DEPLOYMENT-CHECKLIST.md
(Phase 3 to 5). That takes about 20 minutes.

## Changing the API address (only if the website is hosted separately)

By default the server serves the website, so nothing needs changing.
If you put the `public/` folder on a different host (Netlify, GitHub Pages, your
current website), edit `public/config.js`:

```js
API_BASE_URL: 'https://first-driving-school.onrender.com',   // no slash at the end
```

then on the server set `ALLOWED_ORIGINS` to that website's address, and raise
`CACHE_VERSION` in `public/service-worker.js`. Details: DEPLOYMENT-CHECKLIST.md, Phase 8.
