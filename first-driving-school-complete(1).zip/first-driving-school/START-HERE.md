# START HERE - First Driving School booking system

Customers book a driving lesson on your website (or the app on their iPhone),
and your staff manage every booking from a dashboard.

```
First Driving School  ->  booking website  ->  PWA  ->  on the iPhone home screen
```

## What is in this project

| Part | File(s) | What it does |
|---|---|---|
| Booking website | `public/index.html`, `public/js/booking.js` | Licence code (B, A1, C1, C1E) > package > date and time > details > confirm. Gives a booking reference, WhatsApp link and calendar file. |
| Staff dashboard | `public/staff.html`, `public/js/staff.js` | Staff login, bookings by day or next 30 days, confirm / complete / no-show / cancel, reschedule, phone-in bookings, instructors, opening hours, time off, packages and prices, passwords. |
| Backend / API | `backend-server.js`, `src/` | Serves the website and the API, checks free times, assigns instructors, blocks double bookings. |
| Database | `src/db/` | PostgreSQL for real use. Without a database it uses a test file so you can try everything for free. |
| PWA | `public/manifest.json`, `public/service-worker.js`, `public/icons/` | Makes the site installable with "Add to Home Screen" on iPhone. |
| Settings | `.env.example`, `public/config.js` | Server settings and the frontend API address. No secrets are stored in the code. |
| Checks | `npm run check`, `npm test` | Confirms no file is missing and runs 35 end-to-end tests. |

## Which guide do I read?

1. **QUICK-START.md** - run it on your own computer in 5 minutes, free, no accounts.
2. **DEPLOYMENT-CHECKLIST.md** - put it online for free (Render + Neon), test it on an iPhone, then go live.
3. **README.md** - technical reference: folders, settings, API routes.

## The free route (no card needed)

| Stage | Where | Cost |
|---|---|---|
| Try it | Your computer (`npm start`) | Free |
| Online test with HTTPS (needed for iPhone app install) | Render free web service | Free |
| Database that keeps bookings | Neon free PostgreSQL | Free |

Heroku is **not** needed. Heroku no longer has a free plan.

## Things to change before real customers use it

- [ ] Prices: Staff dashboard > Packages. **The prices in the project are examples.**
- [ ] Instructors: Staff dashboard > Instructors (starts with Andre, Bee, Boyboy, Emanuel).
- [ ] Opening hours and public holidays: Staff dashboard > Schedule.
- [ ] Phone and WhatsApp number: `public/config.js` (set to 081 449 1352).
- [ ] Your admin password: Staff dashboard > My account.
