'use strict';
/**
 * First Driving School - booking server.
 *
 *   npm install
 *   npm start            -> http://localhost:3000        (booking website)
 *                           http://localhost:3000/staff.html  (staff dashboard)
 *
 * Serves the website/PWA from ./public and the JSON API under /api.
 * Configuration comes from environment variables - see .env.example.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const config = require('./src/config');
const { Router, HttpError, sendJson, readJsonBody } = require('./src/http');
const { createStore, migrate } = require('./src/db');
const registerPublicRoutes = require('./src/routes/public');
const registerStaffRoutes = require('./src/routes/staff');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data:",
    `connect-src 'self'${config.allowedOrigins.length ? ' ' + config.allowedOrigins.join(' ') : ''}`,
    "manifest-src 'self'",
    "worker-src 'self'",
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'self'",
  ].join('; '),
};

function clientIp(req) {
  if (config.trustProxy && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim();
  return req.socket.remoteAddress || 'unknown';
}

function applyCors(req, res) {
  const origin = (req.headers.origin || '').replace(/\/$/, '');
  if (origin && config.allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Max-Age', '600');
  }
}

function serveStatic(req, res, pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { rel = '/'; }
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(config.PUBLIC_DIR, rel));
  if (!file.startsWith(config.PUBLIC_DIR + path.sep)) return notFound(res);

  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) return notFound(res);
    const ext = path.extname(file).toLowerCase();
    const base = path.basename(file);
    // HTML, config, manifest and service worker must always be fresh so updates reach phones.
    const noCache = ext === '.html' || ['service-worker.js', 'config.js', 'manifest.json', 'manifest-staff.json'].includes(base);
    const type = base.startsWith('manifest') && ext === '.json' ? 'application/manifest+json' : (MIME[ext] || 'application/octet-stream');
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': stat.size,
      'Cache-Control': noCache ? 'no-cache' : 'public, max-age=3600',
      ...(base === 'service-worker.js' ? { 'Service-Worker-Allowed': '/' } : {}),
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

function notFound(res) {
  const page = path.join(config.PUBLIC_DIR, '404.html');
  if (fs.existsSync(page)) {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    fs.createReadStream(page).pipe(res);
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
}

async function main() {
  const db = createStore();
  if (config.autoMigrate) await migrate(db);
  else await db.init();

  const router = new Router();
  registerPublicRoutes(router);
  registerStaffRoutes(router);

  const server = http.createServer(async (req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    if (config.isProduction) res.setHeader('Strict-Transport-Security', 'max-age=15552000');

    const url = new URL(req.url, 'http://localhost');
    const pathname = url.pathname;

    if (!pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'Method not allowed' });
      return serveStatic(req, res, pathname);
    }

    applyCors(req, res);
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

    const started = Date.now();
    try {
      const match = router.match(req.method, pathname);
      if (!match) throw new HttpError(404, 'API route not found.');
      if (match.methodNotAllowed) throw new HttpError(405, 'Method not allowed.');
      const ctx = { req, res, db, params: match.params, query: url.searchParams, body: await readJsonBody(req), ip: clientIp(req), status: 200 };
      let result;
      for (const handler of match.route.handlers) result = await handler(ctx);
      sendJson(res, ctx.status, result ?? { ok: true });
    } catch (err) {
      const status = err instanceof HttpError ? err.status : 500;
      if (status === 500) console.error(`[api] ${req.method} ${pathname}`, err);
      sendJson(res, status, { error: status === 500 ? 'Something went wrong on the server. Please try again.' : err.message, fields: err.details || undefined });
    } finally {
      if (!config.isProduction || res.statusCode >= 500) console.log(`[api] ${req.method} ${pathname} ${res.statusCode} ${Date.now() - started}ms`);
    }
  });

  server.listen(config.port, () => {
    console.log(`\nFirst Driving School is running`);
    console.log(`  Booking website : http://localhost:${config.port}/`);
    console.log(`  Staff dashboard : http://localhost:${config.port}/staff.html`);
    console.log(`  API health      : http://localhost:${config.port}/api/health\n`);
  });

  const shutdown = (sig) => {
    console.log(`[server] ${sig} received, shutting down`);
    server.close(() => db.close().finally(() => process.exit(0)));
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((err) => {
  console.error('[server] Failed to start:', err.message);
  process.exit(1);
});
