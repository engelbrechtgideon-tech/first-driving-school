#!/usr/bin/env node
'use strict';
/**
 * Creates the database tables and starter data (instructors, example packages,
 * opening hours, first admin account). Safe to run more than once.
 *
 *   npm run migrate
 *
 * Uses DATABASE_URL from .env / environment. Without DATABASE_URL it prepares
 * the JSON test database instead. The server also runs this automatically on
 * start-up when AUTO_MIGRATE=true (the default), so on free hosting without a
 * shell you never need to run it by hand.
 */
const { createStore, migrate } = require('../src/db');

(async () => {
  const db = createStore();
  try {
    await migrate(db);
    console.log('[migrate] Done.');
  } catch (err) {
    console.error('[migrate] Failed:', err.message);
    process.exitCode = 1;
  } finally {
    await db.close();
  }
})();
