#!/usr/bin/env node
'use strict';
/**
 * Checks that the project is complete:
 *  - every file referenced by package.json exists
 *  - every local file referenced by the HTML pages, manifests and service worker exists
 *  - every relative require() in the backend resolves
 *  - every JavaScript file has valid syntax
 *
 *   npm run check
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const PUB = path.join(ROOT, 'public');
const problems = [];
let checked = 0;

const exists = (abs, from) => { checked += 1; if (!fs.existsSync(abs)) problems.push(`Missing: ${path.relative(ROOT, abs)}  (referenced by ${from})`); };

// 1. package.json
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
exists(path.join(ROOT, pkg.main), 'package.json "main"');
for (const [name, cmd] of Object.entries(pkg.scripts || {})) {
  for (const m of cmd.matchAll(/node(?:\s+--\S+)*\s+([\w./-]+\.js)/g)) exists(path.join(ROOT, m[1]), `package.json script "${name}"`);
}

// 2. Required project files
const required = [
  'backend-server.js', '.env.example', 'README.md', 'START-HERE.md', 'QUICK-START.md', 'DEPLOYMENT-CHECKLIST.md', 'render.yaml',
  'scripts/migrate.js', 'src/db/schema.sql',
  'public/index.html', 'public/staff.html', 'public/manifest.json', 'public/manifest-staff.json', 'public/service-worker.js',
  'public/config.js', 'public/offline.html', 'public/icons/apple-touch-icon.png', 'public/icons/icon-192.png', 'public/icons/icon-512.png',
];
required.forEach((f) => exists(path.join(ROOT, f), 'required file list'));

// 3. HTML references (src / href), skipping external links, anchors, tel:, mailto:
for (const file of fs.readdirSync(PUB).filter((f) => f.endsWith('.html'))) {
  const html = fs.readFileSync(path.join(PUB, file), 'utf8');
  for (const m of html.matchAll(/\b(?:src|href)="([^"]+)"/g)) {
    const ref = m[1];
    if (/^(https?:|tel:|mailto:|data:|#)/.test(ref) || ref === './' || ref === '/') continue;
    const clean = ref.split(/[?#]/)[0];
    const abs = clean.startsWith('/') ? path.join(PUB, clean) : path.join(PUB, clean);
    exists(abs, `public/${file}`);
  }
}

// 4. Manifests
for (const mf of ['manifest.json', 'manifest-staff.json']) {
  const m = JSON.parse(fs.readFileSync(path.join(PUB, mf), 'utf8'));
  for (const icon of m.icons) exists(path.join(PUB, icon.src), `public/${mf}`);
  exists(path.join(PUB, m.start_url.split('?')[0]), `public/${mf} start_url`);
  const needed = ['name', 'short_name', 'start_url', 'display', 'icons'];
  needed.forEach((k) => { if (!m[k]) problems.push(`public/${mf} is missing "${k}"`); });
  if (!m.icons.some((i) => i.sizes === '192x192') || !m.icons.some((i) => i.sizes === '512x512')) problems.push(`public/${mf} needs 192x192 and 512x512 icons`);
}

// 5. Service worker app shell
const sw = fs.readFileSync(path.join(PUB, 'service-worker.js'), 'utf8');
const shell = sw.match(/APP_SHELL\s*=\s*\[([\s\S]*?)\]/);
if (!shell) problems.push('service-worker.js: APP_SHELL list not found');
else for (const m of shell[1].matchAll(/'([^']+)'/g)) { if (m[1] !== './') exists(path.join(PUB, m[1]), 'public/service-worker.js APP_SHELL'); }

// 6. Backend requires + syntax of every JS file
const jsFiles = [];
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'data', '.git'].includes(e.name)) continue;
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) walk(abs); else if (e.name.endsWith('.js')) jsFiles.push(abs);
  }
})(ROOT);
for (const f of jsFiles) {
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/require\(\s*'(\.{1,2}\/[^']+)'\s*\)/g)) {
    const base = path.resolve(path.dirname(f), m[1]);
    const ok = [base, `${base}.js`, `${base}.json`, path.join(base, 'index.js')].some((p) => fs.existsSync(p));
    checked += 1;
    if (!ok) problems.push(`Cannot resolve require('${m[1]}') in ${path.relative(ROOT, f)}`);
  }
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); checked += 1; } catch (e) { problems.push(`Syntax error in ${path.relative(ROOT, f)}:\n${e.stderr}`); }
}

// 7. JSON files parse
for (const f of ['package.json', 'public/manifest.json', 'public/manifest-staff.json']) {
  try { JSON.parse(fs.readFileSync(path.join(ROOT, f), 'utf8')); } catch (e) { problems.push(`Invalid JSON in ${f}: ${e.message}`); }
}

if (problems.length) {
  console.error(`\nProject check FAILED (${problems.length} problem${problems.length > 1 ? 's' : ''}):\n`);
  problems.forEach((p) => console.error(`  - ${p}`));
  process.exit(1);
}
console.log(`Project check passed: ${checked} references and ${jsFiles.length} JavaScript files OK.`);
