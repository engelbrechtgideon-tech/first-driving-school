#!/usr/bin/env node
'use strict';
/**
 * End-to-end test. Starts the real server on a spare port with a throw-away
 * JSON database, then walks through the customer booking flow and the staff
 * dashboard API. Nothing touches your real database.
 *
 *   npm test
 */
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');
const PORT = 3900 + Math.floor(Math.random() * 90);
const DATA = path.join(os.tmpdir(), `fds-smoke-${process.pid}.json`);
const BASE = `http://127.0.0.1:${PORT}`;
const ADMIN = { email: 'smoke@test.local', password: 'smoke-test-pass' };

let passed = 0;
async function step(name, fn) {
  try { await fn(); passed += 1; console.log(`  ok   ${name}`); } catch (err) { console.error(`  FAIL ${name}\n       ${err.message}`); throw err; }
}

async function req(method, p, body, token) {
  const res = await fetch(BASE + p, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, json, text, headers: res.headers };
}

async function waitForServer() {
  for (let i = 0; i < 50; i += 1) {
    try { const r = await fetch(`${BASE}/api/health`); if (r.ok) return; } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error('Server did not start');
}

(async () => {
  const env = {
    ...process.env, NODE_ENV: 'development', PORT: String(PORT), DATABASE_URL: '', DATA_FILE: DATA,
    ADMIN_EMAIL: ADMIN.email, ADMIN_PASSWORD: ADMIN.password, JWT_SECRET: 'x'.repeat(40), ALLOWED_ORIGINS: '',
  };
  const server = spawn(process.execPath, ['backend-server.js'], { cwd: ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = '';
  server.stdout.on('data', (d) => { log += d; });
  server.stderr.on('data', (d) => { log += d; });

  let failed = false;
  try {
    await waitForServer();
    console.log(`\nSmoke test against ${BASE}\n`);

    // ---------- website / PWA files ----------
    await step('index.html is served', async () => {
      const r = await req('GET', '/');
      assert.equal(r.status, 200);
      assert.match(r.text, /Book your driving lesson/);
      assert.match(r.text, /rel="manifest"/);
      assert.match(r.text, /apple-touch-icon/);
    });
    await step('staff.html is served', async () => { const r = await req('GET', '/staff.html'); assert.equal(r.status, 200); assert.match(r.text, /Staff login/); });
    await step('manifest.json has manifest content type', async () => {
      const r = await req('GET', '/manifest.json');
      assert.equal(r.status, 200);
      assert.match(r.headers.get('content-type'), /manifest\+json/);
      assert.equal(r.json.display, 'standalone');
    });
    await step('service-worker.js is served without caching', async () => {
      const r = await req('GET', '/service-worker.js');
      assert.equal(r.status, 200);
      assert.equal(r.headers.get('cache-control'), 'no-cache');
    });
    await step('icons are served', async () => {
      for (const f of ['icons/icon-192.png', 'icons/icon-512.png', 'icons/apple-touch-icon.png']) {
        const r = await fetch(`${BASE}/${f}`); assert.equal(r.status, 200, f); assert.equal(r.headers.get('content-type'), 'image/png');
      }
    });
    await step('path traversal is blocked', async () => { const r = await fetch(`${BASE}/..%2f.env.example`); assert.equal(r.status, 404); });
    await step('unknown page returns 404', async () => { const r = await req('GET', '/nope.html'); assert.equal(r.status, 404); });

    // ---------- customer flow ----------
    let catalog;
    await step('GET /api/catalog lists B, A1, C1, C1E and packages', async () => {
      const r = await req('GET', '/api/catalog');
      assert.equal(r.status, 200);
      catalog = r.json;
      assert.deepEqual(catalog.licenseCodes.map((c) => c.code), ['B', 'A1', 'C1', 'C1E']);
      assert.ok(catalog.licenseCodes.every((c) => c.available));
      assert.ok(catalog.packages.length >= 13);
    });

    const pkgB = () => catalog.packages.find((p) => p.code === 'B' && p.name === 'Single lesson');
    const pkgC1 = () => catalog.packages.find((p) => p.code === 'C1' && p.name === 'Single lesson');
    let day;
    await step('GET /api/availability/days finds an open day', async () => {
      const r = await req('GET', `/api/availability/days?code=C1&packageId=${pkgC1().id}&days=14`);
      assert.equal(r.status, 200);
      day = r.json.days.find((d) => d.open && d.freeSlots > 2);
      assert.ok(day, 'no open day found in the next 14 days');
      assert.ok(r.json.days.some((d) => d.reason === 'closed'), 'Sunday should be closed');
    });

    let slot;
    await step('GET /api/availability returns times for that day', async () => {
      const r = await req('GET', `/api/availability?code=C1&packageId=${pkgC1().id}&date=${day.date}`);
      assert.equal(r.status, 200);
      slot = r.json.slots.find((s) => s.available);
      assert.ok(slot);
    });

    const customer = { customerName: 'Test Customer', customerPhone: '081 234 5678', customerEmail: 'test@example.com', pickupLocation: 'Klein Windhoek', notes: 'Smoke test' };
    let booking;
    await step('POST /api/bookings creates a booking with reference', async () => {
      const r = await req('POST', '/api/bookings', { licenseCode: 'C1', packageId: pkgC1().id, lessonDate: day.date, startTime: slot.time, ...customer });
      assert.equal(r.status, 201, r.text);
      booking = r.json.booking;
      assert.match(booking.reference, /^FDS-[A-Z0-9]{6}$/);
      assert.equal(booking.status, 'pending');
      assert.equal(booking.instructorName, 'Emanuel');
    });

    await step('double booking the only C1 instructor is refused (409)', async () => {
      const r = await req('POST', '/api/bookings', { licenseCode: 'C1', packageId: pkgC1().id, lessonDate: day.date, startTime: slot.time, ...customer, customerName: 'Second Person' });
      assert.equal(r.status, 409, r.text);
    });

    await step('booked time now shows as taken', async () => {
      const r = await req('GET', `/api/availability?code=C1&packageId=${pkgC1().id}&date=${day.date}`);
      assert.equal(r.json.slots.find((s) => s.time === slot.time).available, false);
    });

    await step('Code B has 3 instructors: three bookings same time, fourth refused', async () => {
      const r0 = await req('GET', `/api/availability?code=B&packageId=${pkgB().id}&date=${day.date}`);
      const t = r0.json.slots.filter((s) => s.available).pop().time;
      const names = [];
      for (let i = 0; i < 3; i += 1) {
        const r = await req('POST', '/api/bookings', { licenseCode: 'B', packageId: pkgB().id, lessonDate: day.date, startTime: t, ...customer, customerName: `B learner ${i}` });
        assert.equal(r.status, 201, r.text);
        names.push(r.json.booking.instructorName);
      }
      assert.equal(new Set(names).size, 3, 'each booking should get a different instructor');
      const r4 = await req('POST', '/api/bookings', { licenseCode: 'B', packageId: pkgB().id, lessonDate: day.date, startTime: t, ...customer });
      assert.equal(r4.status, 409);
    });

    await step('invalid booking returns field errors (422)', async () => {
      const r = await req('POST', '/api/bookings', { licenseCode: 'B', packageId: pkgB().id, lessonDate: day.date, startTime: slot.time, customerName: 'X', customerPhone: '12' });
      assert.equal(r.status, 422);
      assert.ok(r.json.fields.customerName && r.json.fields.customerPhone);
    });

    await step('package from another licence code is refused', async () => {
      const r = await req('POST', '/api/bookings', { licenseCode: 'B', packageId: pkgC1().id, lessonDate: day.date, startTime: slot.time, ...customer });
      assert.equal(r.status, 422);
    });

    await step('customer can look up booking with reference + phone', async () => {
      const ok = await req('GET', `/api/bookings/${booking.reference}?phone=0812345678`);
      assert.equal(ok.status, 200);
      const bad = await req('GET', `/api/bookings/${booking.reference}?phone=0819999999`);
      assert.equal(bad.status, 404);
    });

    // ---------- staff ----------
    await step('staff API requires login (401)', async () => { const r = await req('GET', '/api/staff/bookings'); assert.equal(r.status, 401); });
    await step('wrong password is refused', async () => { const r = await req('POST', '/api/auth/login', { email: ADMIN.email, password: 'wrong-password' }); assert.equal(r.status, 401); });

    let token;
    await step('staff login returns a token', async () => {
      const r = await req('POST', '/api/auth/login', ADMIN);
      assert.equal(r.status, 200, r.text);
      token = r.json.token;
      assert.equal(r.json.user.role, 'admin');
    });

    await step('staff sees bookings for the day', async () => {
      const r = await req('GET', `/api/staff/bookings?date=${day.date}`, null, token);
      assert.equal(r.status, 200);
      assert.equal(r.json.bookings.length, 4);
    });

    await step('staff search by reference', async () => {
      const r = await req('GET', `/api/staff/bookings?q=${booking.reference}`, null, token);
      assert.equal(r.json.bookings.length, 1);
    });

    let full;
    await step('staff confirms a booking', async () => {
      const list = await req('GET', `/api/staff/bookings?q=${booking.reference}`, null, token);
      full = list.json.bookings[0];
      const r = await req('PATCH', `/api/staff/bookings/${full.id}`, { status: 'confirmed', staffNotes: 'Called customer' }, token);
      assert.equal(r.status, 200, r.text);
      assert.equal(r.json.booking.status, 'confirmed');
    });

    await step('staff reschedules the booking to another free time', async () => {
      const av = await req('GET', `/api/staff/availability?code=C1&date=${day.date}&durationMin=60&excludeBookingId=${full.id}`, null, token);
      const other = av.json.slots.find((s) => s.available && s.time !== full.startTime);
      const r = await req('PATCH', `/api/staff/bookings/${full.id}`, { startTime: other.time }, token);
      assert.equal(r.status, 200, r.text);
      assert.equal(r.json.booking.startTime, other.time);
    });

    await step('staff creates a phone-in booking', async () => {
      const av = await req('GET', `/api/staff/availability?code=A1&date=${day.date}&durationMin=60`, null, token);
      const t = av.json.slots.find((s) => s.available).time;
      const a1 = catalog.packages.find((p) => p.code === 'A1');
      const r = await req('POST', '/api/staff/bookings', { licenseCode: 'A1', packageId: a1.id, lessonDate: day.date, startTime: t, customerName: 'Walk In', customerPhone: '0811111111' }, token);
      assert.equal(r.status, 201, r.text);
      assert.equal(r.json.booking.status, 'confirmed');
    });

    await step('staff cancels a booking and the time frees up', async () => {
      const r = await req('PATCH', `/api/staff/bookings/${full.id}`, { status: 'cancelled' }, token);
      assert.equal(r.status, 200);
      const av = await req('GET', `/api/availability?code=C1&packageId=${pkgC1().id}&date=${day.date}`);
      assert.equal(av.json.slots.find((s) => s.time === r.json.booking.startTime).available, true);
    });

    let newInstructor;
    await step('instructor management: add, edit, remove', async () => {
      const c = await req('POST', '/api/staff/instructors', { name: 'New Trainer', phone: '0810000000', codes: ['C1', 'c1e'] }, token);
      assert.equal(c.status, 201, c.text);
      newInstructor = c.json.instructor;
      assert.deepEqual(newInstructor.codes, ['C1', 'C1E']);
      const u = await req('PATCH', `/api/staff/instructors/${newInstructor.id}`, { notes: 'Weekends' }, token);
      assert.equal(u.json.instructor.notes, 'Weekends');
      const bad = await req('POST', '/api/staff/instructors', { name: 'No Codes', codes: [] }, token);
      assert.equal(bad.status, 422);
      const d = await req('DELETE', `/api/staff/instructors/${newInstructor.id}`, null, token);
      assert.equal(d.json.deleted, true);
    });

    await step('schedule management: save opening hours', async () => {
      const g = await req('GET', '/api/staff/schedule', null, token);
      const hours = { ...g.json.schedule.hours, 6: null };
      const r = await req('PUT', '/api/staff/schedule', { hours, minNoticeHours: 2 }, token);
      assert.equal(r.status, 200, r.text);
      assert.equal(r.json.schedule.minNoticeHours, 2);
      const bad = await req('PUT', '/api/staff/schedule', { hours: { ...hours, 1: { open: '17:00', close: '08:00' } } }, token);
      assert.equal(bad.status, 422);
    });

    await step('time off: closing the school blocks the day', async () => {
      const r = await req('POST', '/api/staff/time-off', { date: day.date, reason: 'Public holiday' }, token);
      assert.equal(r.status, 201, r.text);
      const av = await req('GET', `/api/availability?code=B&packageId=${pkgB().id}&date=${day.date}`);
      assert.equal(av.json.open, false);
      const del = await req('DELETE', `/api/staff/time-off/${r.json.timeOff.id}`, null, token);
      assert.equal(del.status, 200);
    });

    await step('packages: edit price and hide a package', async () => {
      const r = await req('PATCH', `/api/staff/packages/${pkgB().id}`, { price: 400 }, token);
      assert.equal(r.json.package.price, 400);
      const h = await req('PATCH', `/api/staff/packages/${pkgB().id}`, { active: false }, token);
      assert.equal(h.json.package.active, false);
      const cat = await req('GET', '/api/catalog');
      assert.ok(!cat.json.packages.some((p) => p.id === pkgB().id));
      await req('PATCH', `/api/staff/packages/${pkgB().id}`, { active: true }, token);
    });

    await step('stats endpoint works', async () => {
      const r = await req('GET', '/api/staff/stats', null, token);
      assert.equal(r.status, 200);
      assert.ok(typeof r.json.pendingCount === 'number');
    });

    await step('admin adds a staff login; new user can log in', async () => {
      const r = await req('POST', '/api/staff/users', { name: 'Bee', email: 'bee@test.local', password: 'bee-password', role: 'staff' }, token);
      assert.equal(r.status, 201, r.text);
      const l = await req('POST', '/api/auth/login', { email: 'bee@test.local', password: 'bee-password' });
      assert.equal(l.status, 200);
      const forbidden = await req('POST', '/api/staff/users', { name: 'X', email: 'x@test.local', password: 'xxxxxxxx' }, l.json.token);
      assert.equal(forbidden.status, 403);
    });

    await step('change password', async () => {
      const r = await req('POST', '/api/auth/change-password', { currentPassword: ADMIN.password, newPassword: 'a-new-password' }, token);
      assert.equal(r.status, 200, r.text);
      const l = await req('POST', '/api/auth/login', { email: ADMIN.email, password: 'a-new-password' });
      assert.equal(l.status, 200);
    });

    await step('tampered token is rejected', async () => {
      const r = await req('GET', '/api/auth/me', null, `${token.slice(0, -2)}xx`);
      assert.equal(r.status, 401);
    });

    await step('unknown API route returns JSON 404', async () => { const r = await req('GET', '/api/does-not-exist'); assert.equal(r.status, 404); assert.ok(r.json.error); });

    console.log(`\nAll ${passed} checks passed.\n`);
  } catch (err) {
    failed = true;
    console.error('\nServer log:\n' + log);
  } finally {
    server.kill('SIGTERM');
    fs.rmSync(DATA, { force: true });
    fs.rmSync(`${DATA}.tmp`, { force: true });
    process.exitCode = failed ? 1 : 0;
  }
})();
