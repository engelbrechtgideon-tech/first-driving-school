/**
 * First Driving School - frontend settings.
 * ------------------------------------------------------------------
 * API_BASE_URL - where the booking server (backend-server.js) runs.
 *
 *   ''  (empty)  = same website that serves this page. Use this when the
 *                  backend serves the frontend (local testing, Render) - the default.
 *
 *   'https://fds-booking.onrender.com'  = backend on another address. Use this
 *                  when index.html is hosted separately (Netlify, GitHub Pages,
 *                  your own web host). No slash at the end. Also add this
 *                  website's address to ALLOWED_ORIGINS on the backend.
 *
 * After changing this file, also raise CACHE_VERSION in service-worker.js
 * so installed iPhone apps pick up the change.
 * ------------------------------------------------------------------
 */
window.FDS_CONFIG = {
  API_BASE_URL: '',

  SCHOOL_NAME: 'First Driving School',
  SCHOOL_CITY: 'Windhoek',
  // Shown as "Call us" and used for the WhatsApp confirmation link.
  PHONE_DISPLAY: '081 449 1352',
  PHONE_TEL: '+264814491352',
  WHATSAPP_NUMBER: '264814491352', // international format, digits only
  CURRENCY: 'N$',
};
