/* Shared API helper. Reads the server address from config.js (window.FDS_CONFIG.API_BASE_URL). */
(function () {
  const cfg = window.FDS_CONFIG || {};
  const base = String(cfg.API_BASE_URL || '').replace(/\/$/, '');

  class ApiError extends Error {
    constructor(message, status, fields) {
      super(message);
      this.status = status;
      this.fields = fields || {};
    }
  }

  async function request(method, path, body, token) {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (token) headers.Authorization = `Bearer ${token}`;
    let res;
    try {
      res = await fetch(`${base}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    } catch (e) {
      throw new ApiError(navigator.onLine === false
        ? 'You are offline. Connect to the internet and try again.'
        : 'Cannot reach the booking server. It may be starting up - wait 30 seconds and try again.', 0);
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* empty body */ }
    if (!res.ok) throw new ApiError((data && data.error) || `Request failed (${res.status}).`, res.status, data && data.fields);
    return data;
  }

  const money = (n) => `${cfg.CURRENCY || 'N$'} ${Number(n || 0).toLocaleString('en-ZA', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

  function formatDate(iso, opts) {
    const d = new Date(`${iso}T12:00:00`);
    return d.toLocaleDateString('en-GB', opts || { weekday: 'long', day: 'numeric', month: 'long' });
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function addMinutes(time, mins) {
    const [h, m] = time.split(':').map(Number);
    const t = h * 60 + m + mins;
    return `${String(Math.floor(t / 60) % 24).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
  }

  window.FDS = {
    config: cfg,
    ApiError,
    get: (p, token) => request('GET', p, undefined, token),
    post: (p, b, token) => request('POST', p, b || {}, token),
    put: (p, b, token) => request('PUT', p, b || {}, token),
    patch: (p, b, token) => request('PATCH', p, b || {}, token),
    del: (p, token) => request('DELETE', p, undefined, token),
    money,
    formatDate,
    escapeHtml,
    addMinutes,
  };
})();
