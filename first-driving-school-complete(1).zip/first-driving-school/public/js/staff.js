/* Staff dashboard: login, bookings, instructors, schedule/time off, packages, account. */
(function () {
  const api = window.FDS;
  const { money, formatDate, escapeHtml: esc, addMinutes } = api;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const CODES = ['B', 'A1', 'C1', 'C1E'];
  const STATUS_TEXT = { pending: 'Pending', confirmed: 'Confirmed', completed: 'Completed', cancelled: 'Cancelled', no_show: 'No-show' };
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const TOKEN_KEY = 'fds-staff-token';

  const state = { token: null, user: null, instructors: [], packages: [], today: null, date: null, upcoming: false, editing: null };

  // ---------- token storage ----------
  const store = {
    get() { try { return localStorage.getItem(TOKEN_KEY); } catch (e) { return state.token; } },
    set(t) { state.token = t; try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch (e) { /* ignore */ } },
  };

  // Authenticated API wrappers; a 401 sends staff back to the login screen.
  async function call(fn, ...args) {
    try {
      return await fn(...args, state.token);
    } catch (err) {
      if (err.status === 401) { logout(err.message); }
      throw err;
    }
  }
  const aget = (p) => call(api.get, p);
  const apost = (p, b) => call(api.post, p, b);
  const aput = (p, b) => call(api.put, p, b);
  const apatch = (p, b) => call(api.patch, p, b);
  const adel = (p) => call(api.del, p);

  let toastTimer;
  function toast(msg, isError) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.toggle('toast-error', Boolean(isError));
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, isError ? 6000 : 3000);
  }

  const localToday = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  const shiftDate = (iso, n) => { const d = new Date(`${iso}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  const instructorName = (id) => (state.instructors.find((i) => i.id === id) || {}).name || 'Unassigned';
  const waLink = (phone, text) => {
    let digits = String(phone || '').replace(/\D/g, '');
    if (digits.startsWith('0')) digits = `264${digits.slice(1)}`; // Namibian local number -> international
    return `https://wa.me/${digits}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
  };

  // ---------- login ----------
  function showLogin(message) {
    $('#app-view').hidden = true;
    $('#login-view').hidden = false;
    $('#login-error').textContent = message || '';
    $('#login-email').focus();
  }

  function logout(message) {
    store.set(null);
    state.user = null;
    showLogin(message);
  }

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('#login-form button[type="submit"]');
    btn.disabled = true;
    $('#login-error').textContent = '';
    try {
      const { token, user } = await api.post('/api/auth/login', { email: $('#login-email').value.trim(), password: $('#login-password').value });
      store.set(token);
      state.user = user;
      $('#login-password').value = '';
      await startApp();
    } catch (err) {
      $('#login-error').textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  $('#logout-btn').addEventListener('click', () => logout('You are logged out.'));

  // ---------- tabs ----------
  function openTab(name) {
    $$('.tab').forEach((t) => (t.dataset.tab === name ? t.setAttribute('aria-current', 'page') : t.removeAttribute('aria-current')));
    $$('.panel').forEach((p) => { p.hidden = p.dataset.panel !== name; });
    if (name === 'bookings') loadBookings();
    if (name === 'instructors') renderInstructors();
    if (name === 'schedule') loadSchedule();
    if (name === 'packages') loadPackages().then(renderPackages);
  }
  $$('.tab').forEach((t) => t.addEventListener('click', () => openTab(t.dataset.tab)));

  // ---------- start ----------
  async function startApp() {
    const { user } = await aget('/api/auth/me');
    state.user = user;
    $('#user-name').textContent = user.name;
    $('#admin-only').hidden = user.role !== 'admin';
    $('#login-view').hidden = true;
    $('#app-view').hidden = false;
    await Promise.all([loadInstructors(), loadPackages()]);
    state.today = state.today || localToday();
    state.date = state.date || state.today;
    $('#filter-date').value = state.date;
    openTab('bookings');
  }

  async function loadInstructors() {
    const { instructors } = await aget('/api/staff/instructors');
    state.instructors = instructors;
    const opts = instructors.map((i) => `<option value="${i.id}">${esc(i.name)}${i.active ? '' : ' (inactive)'}</option>`).join('');
    $('#filter-instructor').innerHTML = `<option value="">All instructors</option>${opts}`;
    $('#to-instructor').innerHTML = `<option value="">Whole school</option>${opts}`;
  }

  async function loadPackages() {
    const { packages } = await aget('/api/staff/packages');
    state.packages = packages;
  }

  // ---------- bookings ----------
  async function loadStats() {
    try {
      const s = await aget('/api/staff/stats');
      state.today = s.today;
      $('#stats').innerHTML = [
        ['Today', s.todayCount],
        ['Waiting for confirmation', s.pendingCount],
        ['Next 30 days', s.upcomingCount],
        ['Confirmed this month', money(s.monthBookedValue)],
      ].map(([k, v]) => `<div class="stat"><span class="stat-value">${esc(v)}</span><span class="stat-label">${esc(k)}</span></div>`).join('');
    } catch (err) { /* stats are optional */ }
  }

  let searchTimer;
  $('#filter-q').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadBookings, 300); });
  $('#filter-status').addEventListener('change', loadBookings);
  $('#filter-instructor').addEventListener('change', loadBookings);
  $('#filter-date').addEventListener('change', () => { if ($('#filter-date').value) { state.date = $('#filter-date').value; setUpcoming(false); } });
  $('#day-prev').addEventListener('click', () => { state.date = shiftDate(state.date, -1); $('#filter-date').value = state.date; setUpcoming(false); });
  $('#day-next').addEventListener('click', () => { state.date = shiftDate(state.date, 1); $('#filter-date').value = state.date; setUpcoming(false); });
  $('#day-today').addEventListener('click', () => { state.date = state.today || localToday(); $('#filter-date').value = state.date; setUpcoming(false); });
  $('#show-upcoming').addEventListener('click', () => setUpcoming(!state.upcoming));

  function setUpcoming(on) {
    state.upcoming = on;
    $('#show-upcoming').setAttribute('aria-pressed', String(on));
    loadBookings();
  }

  async function loadBookings() {
    loadStats();
    const params = new URLSearchParams();
    const q = $('#filter-q').value.trim();
    if (q) {
      // search across all dates
    } else if (state.upcoming) {
      params.set('from', state.today || localToday());
      params.set('to', shiftDate(state.today || localToday(), 30));
    } else {
      params.set('date', state.date);
    }
    if (q) params.set('q', q);
    if ($('#filter-status').value) params.set('status', $('#filter-status').value);
    if ($('#filter-instructor').value) params.set('instructorId', $('#filter-instructor').value);

    $('#bookings-title').textContent = q ? `Search results for "${q}"` : state.upcoming ? 'Next 30 days' : formatDate(state.date);
    const list = $('#bookings-list');
    list.innerHTML = '<p class="muted">Loading bookings…</p>';
    try {
      const { bookings } = await aget(`/api/staff/bookings?${params}`);
      renderBookings(bookings, !q && !state.upcoming);
    } catch (err) {
      list.innerHTML = `<p class="error-text">${esc(err.message)}</p>`;
    }
  }

  function renderBookings(bookings, singleDay) {
    const list = $('#bookings-list');
    if (!bookings.length) {
      list.innerHTML = `<div class="empty"><p>${singleDay ? 'No bookings on this day.' : 'No bookings found.'}</p><p class="muted">Use "New booking" for customers who phone or walk in.</p></div>`;
      return;
    }
    let lastDate = null;
    list.innerHTML = bookings.map((b) => {
      const header = !singleDay && b.lessonDate !== lastDate ? `<h3 class="list-date">${esc(formatDate(b.lessonDate))}</h3>` : '';
      lastDate = b.lessonDate;
      return `${header}<button type="button" class="booking-row status-${esc(b.status)}" data-id="${b.id}">
        <span class="br-time">${esc(b.startTime)}<small>${esc(addMinutes(b.startTime, b.durationMin))}</small></span>
        <span class="br-main">
          <span class="br-name">${esc(b.customerName)}</span>
          <span class="br-sub">Code ${esc(b.licenseCode)}, ${esc(b.packageName)}</span>
          <span class="br-sub">${esc(instructorName(b.instructorId))}${b.pickupLocation ? `, ${esc(b.pickupLocation)}` : ''}</span>
        </span>
        <span class="br-side"><span class="badge badge-${esc(b.status)}">${esc(STATUS_TEXT[b.status] || b.status)}</span><span class="br-ref">${esc(b.reference)}</span></span>
      </button>`;
    }).join('');
    $$('.booking-row', list).forEach((row) => row.addEventListener('click', () => {
      openBooking(bookings.find((b) => b.id === Number(row.dataset.id)));
    }));
  }

  // ---------- booking dialog ----------
  const dlg = $('#booking-dialog');
  $$('dialog [data-close]').forEach((b) => b.addEventListener('click', () => b.closest('dialog').close()));

  function fillCodeAndPackage(code, packageId) {
    $('#bd-code').innerHTML = CODES.map((c) => `<option value="${c}" ${c === code ? 'selected' : ''}>Code ${c}</option>`).join('');
    const pk = state.packages.filter((p) => p.code === code && (p.active || p.id === packageId));
    $('#bd-package').innerHTML = pk.map((p) => `<option value="${p.id}" ${p.id === packageId ? 'selected' : ''}>${esc(p.name)} (${p.durationMin} min, ${esc(money(p.price))})</option>`).join('');
  }

  function openBooking(b) {
    state.editing = b || null;
    const creating = !b;
    $('#bd-title').textContent = creating ? 'New booking' : b.reference;
    $('#bd-error').textContent = '';
    $('#bd-code').disabled = !creating;
    $('#bd-package').disabled = !creating;

    if (creating) {
      $('#bd-meta').innerHTML = '<p class="muted">For customers who phone, WhatsApp or walk in. Staff bookings ignore the minimum notice.</p>';
      $('#bd-actions').innerHTML = '';
      fillCodeAndPackage('B', (state.packages.find((p) => p.code === 'B' && p.active) || {}).id);
      $('#bd-date').value = state.upcoming ? (state.today || localToday()) : state.date;
      $('#bd-status').value = 'confirmed';
      ['#bd-name', '#bd-phone', '#bd-email', '#bd-pickup', '#bd-notes', '#bd-staffnotes'].forEach((s) => { $(s).value = ''; });
    } else {
      $('#bd-meta').innerHTML = `
        <p><span class="badge badge-${esc(b.status)}">${esc(STATUS_TEXT[b.status])}</span>
        Booked ${esc(new Date(b.createdAt).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }))}</p>
        <p class="contact-links"><a class="btn btn-sm btn-whatsapp" target="_blank" rel="noopener" href="${esc(waLink(b.customerPhone, `Hi ${b.customerName}, this is First Driving School about your booking ${b.reference} on ${formatDate(b.lessonDate)} at ${b.startTime}.`))}">WhatsApp</a>
        <a class="btn btn-sm btn-ghost" href="tel:${esc(b.customerPhone.replace(/[^\d+]/g, ''))}">Call ${esc(b.customerPhone)}</a></p>`;
      const quick = [['confirmed', 'Confirm'], ['completed', 'Mark completed'], ['no_show', 'No-show'], ['cancelled', 'Cancel booking']]
        .filter(([s]) => s !== b.status);
      $('#bd-actions').innerHTML = quick.map(([s, label]) => `<button type="button" class="btn btn-sm ${s === 'cancelled' ? 'btn-danger' : 'btn-ghost'}" data-status="${s}">${label}</button>`).join('');
      $$('#bd-actions [data-status]').forEach((btn) => btn.addEventListener('click', () => quickStatus(b, btn.dataset.status)));
      fillCodeAndPackage(b.licenseCode, b.packageId);
      $('#bd-date').value = b.lessonDate;
      $('#bd-status').value = b.status;
      $('#bd-name').value = b.customerName;
      $('#bd-phone').value = b.customerPhone;
      $('#bd-email').value = b.customerEmail || '';
      $('#bd-pickup').value = b.pickupLocation || '';
      $('#bd-notes').value = b.notes || '';
      $('#bd-staffnotes').value = b.staffNotes || '';
    }
    loadTimes();
    dlg.showModal();
  }

  $('#new-booking-btn').addEventListener('click', () => openBooking(null));
  $('#bd-code').addEventListener('change', () => { const c = $('#bd-code').value; fillCodeAndPackage(c, (state.packages.find((p) => p.code === c && p.active) || {}).id); loadTimes(); });
  $('#bd-package').addEventListener('change', loadTimes);
  $('#bd-date').addEventListener('change', loadTimes);
  $('#bd-time').addEventListener('change', fillInstructorOptions);

  let slotCache = [];
  async function loadTimes() {
    const b = state.editing;
    const code = $('#bd-code').value;
    const pkg = state.packages.find((p) => p.id === Number($('#bd-package').value));
    const durationMin = b ? b.durationMin : (pkg ? pkg.durationMin : 60);
    const date = $('#bd-date').value;
    const sel = $('#bd-time');
    if (!date) { sel.innerHTML = ''; return; }
    sel.innerHTML = '<option>Loading…</option>';
    try {
      const qs = new URLSearchParams({ code, date, durationMin });
      if (b) qs.set('excludeBookingId', b.id);
      const day = await aget(`/api/staff/availability?${qs}`);
      slotCache = day.slots;
      const keep = b && b.lessonDate === date ? b.startTime : null;
      const opts = day.slots.filter((s) => s.available || s.time === keep);
      if (keep && !opts.some((s) => s.time === keep)) opts.push({ time: keep, available: false, freeInstructorIds: [] });
      opts.sort((x, y) => x.time.localeCompare(y.time));
      sel.innerHTML = opts.length
        ? opts.map((s) => `<option value="${s.time}" ${s.time === keep ? 'selected' : ''}>${s.time}${s.available ? '' : ' (current)'}</option>`).join('')
        : '<option value="">No free times</option>';
      $('#bd-time-hint').textContent = day.open ? '' : 'The school is closed on this day.';
    } catch (err) {
      sel.innerHTML = '<option value="">Could not load times</option>';
      $('#bd-time-hint').textContent = err.message;
    }
    fillInstructorOptions();
  }

  function fillInstructorOptions() {
    const b = state.editing;
    const slot = slotCache.find((s) => s.time === $('#bd-time').value);
    const free = new Set(slot ? slot.freeInstructorIds : []);
    if (b && b.instructorId && b.lessonDate === $('#bd-date').value && b.startTime === $('#bd-time').value) free.add(b.instructorId);
    const opts = state.instructors.filter((i) => free.has(i.id));
    $('#bd-instructor').innerHTML = `<option value="">Assign automatically</option>${opts.map((i) => `<option value="${i.id}" ${b && b.instructorId === i.id ? 'selected' : ''}>${esc(i.name)}</option>`).join('')}`;
  }

  async function quickStatus(b, status) {
    if (status === 'cancelled' && !confirm(`Cancel booking ${b.reference} for ${b.customerName}?`)) return;
    try {
      await apatch(`/api/staff/bookings/${b.id}`, { status });
      toast(`Booking ${STATUS_TEXT[status].toLowerCase()}.`);
      dlg.close();
      loadBookings();
    } catch (err) {
      $('#bd-error').textContent = err.message;
    }
  }

  $('#booking-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const b = state.editing;
    const payload = {
      lessonDate: $('#bd-date').value,
      startTime: $('#bd-time').value,
      instructorId: $('#bd-instructor').value ? Number($('#bd-instructor').value) : null,
      status: $('#bd-status').value,
      customerName: $('#bd-name').value.trim(),
      customerPhone: $('#bd-phone').value.trim(),
      customerEmail: $('#bd-email').value.trim(),
      pickupLocation: $('#bd-pickup').value.trim(),
      notes: $('#bd-notes').value.trim(),
      staffNotes: $('#bd-staffnotes').value.trim(),
    };
    if (!payload.startTime) { $('#bd-error').textContent = 'Choose a start time.'; return; }
    const btn = $('#bd-save');
    btn.disabled = true;
    try {
      if (b) {
        if (!payload.instructorId) delete payload.instructorId; // keep current or auto-assign
        await apatch(`/api/staff/bookings/${b.id}`, payload);
        toast('Booking saved.');
      } else {
        const { booking } = await apost('/api/staff/bookings', { ...payload, licenseCode: $('#bd-code').value, packageId: Number($('#bd-package').value) });
        toast(`Booking ${booking.reference} added.`);
      }
      dlg.close();
      loadBookings();
    } catch (err) {
      const fields = Object.values(err.fields || {});
      $('#bd-error').textContent = fields.length ? `${err.message} ${fields.join(' ')}` : err.message;
    } finally {
      btn.disabled = false;
    }
  });

  // ---------- instructors ----------
  function renderInstructors() {
    const list = $('#instructor-list');
    list.innerHTML = state.instructors.map((i) => `
      <button type="button" class="row ${i.active ? '' : 'row-inactive'}" data-id="${i.id}">
        <span class="row-main"><strong>${esc(i.name)}</strong>${i.active ? '' : ' <span class="badge">Inactive</span>'}
          <span class="row-sub">${esc(i.phone || 'No phone saved')}${i.notes ? `, ${esc(i.notes)}` : ''}</span></span>
        <span class="code-pills">${i.codes.map((c) => `<span class="pill">${esc(c)}</span>`).join('')}</span>
      </button>`).join('') || '<p class="muted">No instructors yet.</p>';
    $$('.row', list).forEach((r) => r.addEventListener('click', () => openInstructor(state.instructors.find((i) => i.id === Number(r.dataset.id)))));
  }

  const idlg = $('#instructor-dialog');
  function openInstructor(ins) {
    state.editingInstructor = ins || null;
    $('#id-title').textContent = ins ? `Edit ${ins.name}` : 'Add instructor';
    $('#in-name').value = ins ? ins.name : '';
    $('#in-phone').value = ins ? ins.phone : '';
    $('#in-notes').value = ins ? ins.notes : '';
    $('#in-active').checked = ins ? ins.active : true;
    $('#in-codes').innerHTML = CODES.map((c) => `<label class="chip"><input type="checkbox" value="${c}" ${ins && ins.codes.includes(c) ? 'checked' : ''}> Code ${c}</label>`).join('');
    $('#in-delete').hidden = !ins;
    $('#in-error').textContent = '';
    idlg.showModal();
  }
  $('#new-instructor-btn').addEventListener('click', () => openInstructor(null));

  $('#instructor-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const ins = state.editingInstructor;
    const payload = {
      name: $('#in-name').value.trim(),
      phone: $('#in-phone').value.trim(),
      notes: $('#in-notes').value.trim(),
      active: $('#in-active').checked,
      codes: $$('#in-codes input:checked').map((c) => c.value),
    };
    try {
      if (ins) await apatch(`/api/staff/instructors/${ins.id}`, payload);
      else await apost('/api/staff/instructors', payload);
      idlg.close();
      toast('Instructor saved.');
      await loadInstructors();
      renderInstructors();
    } catch (err) {
      $('#in-error').textContent = [err.message, ...Object.values(err.fields || {})].join(' ');
    }
  });

  $('#in-delete').addEventListener('click', async () => {
    const ins = state.editingInstructor;
    if (!ins || !confirm(`Remove ${ins.name}? Instructors with past lessons are set to inactive instead.`)) return;
    try {
      const r = await adel(`/api/staff/instructors/${ins.id}`);
      idlg.close();
      toast(r.deactivated ? `${ins.name} set to inactive.` : `${ins.name} removed.`);
      await loadInstructors();
      renderInstructors();
    } catch (err) {
      $('#in-error').textContent = err.message;
    }
  });

  // ---------- schedule ----------
  async function loadSchedule() {
    try {
      const { schedule } = await aget('/api/staff/schedule');
      $('#hours-rows').innerHTML = [1, 2, 3, 4, 5, 6, 0].map((d) => {
        const h = schedule.hours[d] || schedule.hours[String(d)];
        return `<div class="hours-row" data-day="${d}">
          <label class="check day-name"><input type="checkbox" ${h ? 'checked' : ''}> ${DAYS[d]}</label>
          <input type="time" class="h-open" value="${h ? h.open : '08:00'}" step="900" aria-label="${DAYS[d]} opens" ${h ? '' : 'disabled'}>
          <span class="to">to</span>
          <input type="time" class="h-close" value="${h ? h.close : '17:00'}" step="900" aria-label="${DAYS[d]} closes" ${h ? '' : 'disabled'}>
        </div>`;
      }).join('');
      $$('.hours-row input[type="checkbox"]').forEach((cb) => cb.addEventListener('change', () => {
        $$('input[type="time"]', cb.closest('.hours-row')).forEach((t) => { t.disabled = !cb.checked; });
      }));
      $('#slotMinutes').value = schedule.slotMinutes;
      $('#bookingWindowDays').value = schedule.bookingWindowDays;
      $('#minNoticeHours').value = schedule.minNoticeHours;
    } catch (err) {
      toast(err.message, true);
    }
    loadTimeOff();
  }

  $('#hours-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const hours = {};
    $$('.hours-row').forEach((row) => {
      const on = $('input[type="checkbox"]', row).checked;
      hours[row.dataset.day] = on ? { open: $('.h-open', row).value, close: $('.h-close', row).value } : null;
    });
    try {
      await aput('/api/staff/schedule', {
        hours,
        slotMinutes: Number($('#slotMinutes').value),
        bookingWindowDays: Number($('#bookingWindowDays').value),
        minNoticeHours: Number($('#minNoticeHours').value),
      });
      toast('Opening hours saved.');
    } catch (err) {
      toast([err.message, ...Object.values(err.fields || {})].join(' '), true);
    }
  });

  $('#to-allday').addEventListener('change', () => { $('#to-times').hidden = $('#to-allday').checked; });

  async function loadTimeOff() {
    try {
      const { timeOff } = await aget('/api/staff/time-off');
      $('#timeoff-list').innerHTML = timeOff.map((t) => `
        <div class="row static">
          <span class="row-main"><strong>${esc(formatDate(t.date, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }))}</strong>
          <span class="row-sub">${t.instructorId ? esc(instructorName(t.instructorId)) : 'Whole school'}, ${t.startTime ? `${esc(t.startTime)} to ${esc(t.endTime)}` : 'all day'}${t.reason ? `, ${esc(t.reason)}` : ''}</span></span>
          <button type="button" class="btn btn-sm btn-ghost" data-del="${t.id}">Remove</button>
        </div>`).join('') || '<p class="muted">No time off planned.</p>';
      $$('#timeoff-list [data-del]').forEach((b) => b.addEventListener('click', async () => {
        try { await adel(`/api/staff/time-off/${b.dataset.del}`); toast('Time off removed.'); loadTimeOff(); } catch (err) { toast(err.message, true); }
      }));
    } catch (err) {
      toast(err.message, true);
    }
  }

  $('#timeoff-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const allDay = $('#to-allday').checked;
    try {
      await apost('/api/staff/time-off', {
        instructorId: $('#to-instructor').value ? Number($('#to-instructor').value) : null,
        date: $('#to-date').value,
        startTime: allDay ? null : $('#to-start').value,
        endTime: allDay ? null : $('#to-end').value,
        reason: $('#to-reason').value.trim(),
      });
      toast('Time off added.');
      $('#to-reason').value = '';
      loadTimeOff();
    } catch (err) {
      toast([err.message, ...Object.values(err.fields || {})].join(' '), true);
    }
  });

  // ---------- packages ----------
  function renderPackages() {
    $('#package-list').innerHTML = CODES.map((code) => {
      const list = state.packages.filter((p) => p.code === code);
      return `<h3 class="list-date">Code ${code}</h3><div class="rows">${list.map((p) => `
        <button type="button" class="row ${p.active ? '' : 'row-inactive'}" data-id="${p.id}">
          <span class="row-main"><strong>${esc(p.name)}</strong>${p.active ? '' : ' <span class="badge">Hidden</span>'}
            <span class="row-sub">${p.lessons} x ${p.durationMin} min. ${esc(p.description)}</span></span>
          <span class="row-price">${esc(money(p.price))}</span>
        </button>`).join('') || '<p class="muted">No packages.</p>'}</div>`;
    }).join('');
    $$('#package-list .row').forEach((r) => r.addEventListener('click', () => openPackage(state.packages.find((p) => p.id === Number(r.dataset.id)))));
  }

  const pdlg = $('#package-dialog');
  function openPackage(p) {
    state.editingPackage = p || null;
    $('#pd-title').textContent = p ? 'Edit package' : 'Add package';
    $('#pk-code').innerHTML = CODES.map((c) => `<option value="${c}" ${p && p.code === c ? 'selected' : ''}>Code ${c}</option>`).join('');
    $('#pk-name').value = p ? p.name : '';
    $('#pk-price').value = p ? p.price : '';
    $('#pk-lessons').value = p ? p.lessons : 1;
    $('#pk-duration').value = p ? p.durationMin : 60;
    $('#pk-sort').value = p ? p.sortOrder : 10;
    $('#pk-desc').value = p ? p.description : '';
    $('#pk-active').checked = p ? p.active : true;
    $('#pk-error').textContent = '';
    pdlg.showModal();
  }
  $('#new-package-btn').addEventListener('click', () => openPackage(null));

  $('#package-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const p = state.editingPackage;
    const payload = {
      code: $('#pk-code').value,
      name: $('#pk-name').value.trim(),
      price: Number($('#pk-price').value),
      lessons: Number($('#pk-lessons').value),
      durationMin: Number($('#pk-duration').value),
      sortOrder: Number($('#pk-sort').value || 0),
      description: $('#pk-desc').value.trim(),
      active: $('#pk-active').checked,
    };
    try {
      if (p) await apatch(`/api/staff/packages/${p.id}`, payload);
      else await apost('/api/staff/packages', payload);
      pdlg.close();
      toast('Package saved.');
      await loadPackages();
      renderPackages();
    } catch (err) {
      $('#pk-error').textContent = [err.message, ...Object.values(err.fields || {})].join(' ');
    }
  });

  // ---------- account ----------
  $('#password-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await apost('/api/auth/change-password', { currentPassword: $('#pw-current').value, newPassword: $('#pw-new').value });
      e.target.reset();
      toast('Password changed.');
    } catch (err) {
      toast([err.message, ...Object.values(err.fields || {})].join(' '), true);
    }
  });

  $('#user-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await apost('/api/staff/users', { name: $('#u-name').value.trim(), email: $('#u-email').value.trim(), password: $('#u-password').value, role: $('#u-role').value });
      e.target.reset();
      toast('Staff login added. Share the temporary password privately.');
    } catch (err) {
      toast([err.message, ...Object.values(err.fields || {})].join(' '), true);
    }
  });

  // ---------- boot ----------
  state.token = store.get();
  if (state.token) {
    startApp().catch((err) => { if (err.status !== 401) showLogin(err.message); });
  } else {
    showLogin();
  }
})();
