/* Registers the service worker and shows an "Add to Home Screen" hint on iPhone Safari. */
(function () {
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./service-worker.js').catch((err) => console.warn('Service worker not registered:', err));
    });
  }

  const hint = document.getElementById('install-hint');
  if (!hint) return;
  const ua = navigator.userAgent;
  const isIos = /iphone|ipad|ipod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const standalone = window.navigator.standalone === true || window.matchMedia('(display-mode: standalone)').matches;
  let dismissed = false;
  try { dismissed = localStorage.getItem('fds-install-hint') === 'hidden'; } catch (e) { /* private mode */ }
  if (isIos && !standalone && !dismissed) {
    hint.hidden = false;
    hint.querySelector('button').addEventListener('click', () => {
      hint.hidden = true;
      try { localStorage.setItem('fds-install-hint', 'hidden'); } catch (e) { /* ignore */ }
    });
  }
})();
