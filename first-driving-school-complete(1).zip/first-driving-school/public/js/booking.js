/* Customer booking flow: licence -> package -> date & time -> details -> confirm -> done. */
(function () {
  const { get, post, money, formatDate, escapeHtml: esc, addMinutes, config } = window.FDS;
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const STEP_NAMES = { 1: 'Licence', 2: 'Package', 3: 'Date & time', 4: 'Your details', 5: 'Confirm' };
  const REASONS = { closed: 'Closed', full: 'Full', no_instructor: 'Unavailable', past: 'Past', too_far: '' };

  const state = { catalog: null, code: null, pkg: null, date: null, time: null, nextFrom: null, details: null, booking: null, step: 1 };

  // ---------- helpers ----------
  function showAlert(msg) {
    const el = $('#alert');
    el.textContent = msg || '';
    el.hidden = !msg;
    if (msg) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function goTo(step, push = true) {
    state.step = step;
    $$('.step').forEach((s) => { s.hidden = Number(s.dataset.step) !== step; });
    $$('#road li').forEach((li) => {
      const n = Number(li.dataset.step);
      li.classList.toggle('done', n < step);
      li.classList.toggle('current', n === step);
    });
    $('.road').hidden = step === 6;
    $('.intro').hidden = step !== 1;
    $('#road-label').textContent = step <= 5 ? `Step ${step} of 5: ${STEP_NAMES[step]}` : '';
    showAlert('');
    if (push) history.pushState({ step }, '', `#step-${step}`);
    const heading = $(`.step[data-step="${step}"] h2`);
    if (heading) { heading.setAttribute('tabindex', '-1'); heading.focus({ preventScroll: true }); }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  window.addEventListener('popstate', (e) => {
    const step = (e.state && e.state.step) || 1;
    if (state.step === 6) { history.replaceState({ step: 6 }, '', '#step-6'); return; }
    if (step <= maxReachableStep()) goTo(step, false);
  });

  function maxReachableStep() {
    if (!state.code) return 1;
    if (!state.pkg) return 2;
    if (!state.time) return 3;
    if (!state.details) return 4;
    return 5;
  }

  $$('[data-back]').forEach((b) => b.addEventListener('click', () => history.back()));

  // ---------- step 1: licence ----------
  async function loadCatalog() {
    try {
      state.catalog = await get('/api/catalog');
      renderCodes();
    } catch (err) {
      $('#codes').innerHTML = '';
      const retry = document.createElement('button');
      retry.className = 'btn btn-ghost';
      retry.textContent = 'Try again';
      retry.addEventListener('click', () => { $('#codes').innerHTML = '<p class="loading">Loading licence codes&hellip;</p>'; loadCatalog(); });
      const p = document.createElement('p');
      p.className = 'error-text';
      p.textContent = err.message;
      $('#codes').append(p, retry);
    }
  }

  function renderCodes() {
    const el = $('#codes');
    el.innerHTML = state.catalog.licenseCodes.map((c) => `
      <button type="button" class="code-tile" data-code="${esc(c.code)}" ${c.available ? '' : 'disabled'}>
        <span class="code-glyph">${esc(c.code)}</span>
        <span class="code-vehicle">${esc(c.vehicle)}</span>
        <span class="code-detail">${esc(c.available ? c.detail : 'Not bookable online right now')}</span>
      </button>`).join('');
    $$('.code-tile', el).forEach((b) => b.addEventListener('click', () => {
      state.code = b.dataset.code;
      state.pkg = null; state.date = null; state.time = null;
      renderPackages();
      goTo(2);
    }));
  }

  // ---------- step 2: package ----------
  function renderPackages() {
    const code = state.catalog.licenseCodes.find((c) => c.code === state.code);
    $('#package-sub').textContent = `${code.title}: ${code.vehicle.toLowerCase()}`;
    const list = state.catalog.packages.filter((p) => p.code === state.code);
    $('#packages').innerHTML = list.map((p) => `
      <button type="button" class="package" data-id="${p.id}">
        <span class="package-main">
          <span class="package-name">${esc(p.name)}</span>
          <span class="package-desc">${esc(p.description)}</span>
          <span class="package-meta">${p.lessons > 1 ? `${p.lessons} lessons of ${p.durationMin} min` : `${p.durationMin} minutes`}</span>
        </span>
        <span class="package-price">${esc(money(p.price))}</span>
      </button>`).join('') || '<p class="muted">No packages for this code yet. Please call us.</p>';
    $$('.package').forEach((b) => b.addEventListener('click', () => {
      state.pkg = state.catalog.packages.find((p) => p.id === Number(b.dataset.id));
      state.date = null; state.time = null;
      $('#dates').innerHTML = '';
      $('#times').innerHTML = '';
      $('#times-title').hidden = true;
      $('#times-note').textContent = '';
      $('#to-details').disabled = true;
      state.nextFrom = state.catalog.today;
      goTo(3);
      loadDays(true);
    }));
  }

  // ---------- step 3: date & time ----------
  async function loadDays(autoSelect) {
    const btn = $('#more-dates');
    btn.disabled = true;
    btn.textContent = 'Loading dates…';
    try {
      const data = await get(`/api/availability/days?code=${encodeURIComponent(state.code)}&packageId=${state.pkg.id}&from=${state.nextFrom}&days=14`);
      const visible = data.days.filter((d) => d.reason !== 'too_far' && d.reason !== 'past');
      const frag = document.createDocumentFragment();
      visible.forEach((d) => {
        const ok = d.open && d.freeSlots > 0;
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'date-chip';
        b.dataset.date = d.date;
        b.setAttribute('role', 'option');
        b.disabled = !ok;
        const dt = new Date(`${d.date}T12:00:00`);
        b.innerHTML = `<span class="dow">${dt.toLocaleDateString('en-GB', { weekday: 'short' })}</span>
          <span class="dom">${dt.getDate()}</span>
          <span class="mon">${ok ? dt.toLocaleDateString('en-GB', { month: 'short' }) : esc(REASONS[d.reason] || 'Full')}</span>`;
        b.addEventListener('click', () => selectDate(d.date));
        frag.appendChild(b);
      });
      $('#dates').appendChild(frag);
      const last = data.days[data.days.length - 1].date;
      const next = new Date(`${last}T12:00:00Z`);
      next.setUTCDate(next.getUTCDate() + 1);
      state.nextFrom = next.toISOString().slice(0, 10);
      const reachedEnd = data.days.some((d) => d.reason === 'too_far');
      btn.hidden = reachedEnd;
      if (autoSelect) {
        const first = $('.date-chip:not([disabled])');
        if (first) selectDate(first.dataset.date);
        else if (!reachedEnd) loadDays(true);
        else $('#times-note').textContent = 'No free times in the coming weeks. Please call or WhatsApp us.';
      }
    } catch (err) {
      showAlert(err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = 'Show later dates';
    }
  }

  $('#more-dates').addEventListener('click', () => loadDays(false));

  async function selectDate(date) {
    state.date = date;
    state.time = null;
    $('#to-details').disabled = true;
    $$('.date-chip').forEach((c) => {
      const on = c.dataset.date === date;
      c.classList.toggle('selected', on);
      c.setAttribute('aria-selected', String(on));
    });
    const chip = $(`.date-chip[data-date="${date}"]`);
    if (chip) chip.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    const times = $('#times');
    times.innerHTML = '<p class="loading">Checking free times&hellip;</p>';
    $('#times-title').hidden = false;
    $('#times-title').textContent = `Pick a start time on ${formatDate(date)}`;
    try {
      const data = await get(`/api/availability?code=${encodeURIComponent(state.code)}&packageId=${state.pkg.id}&date=${date}`);
      if (state.date !== date) return; // user clicked another date meanwhile
      if (!data.slots.some((s) => s.available)) {
        times.innerHTML = '<p class="muted">This day just filled up. Choose another date.</p>';
        return;
      }
      times.innerHTML = data.slots.map((s) => `<button type="button" class="time-chip" role="option" data-time="${s.time}" ${s.available ? '' : 'disabled aria-label="' + s.time + ' taken"'}>${s.time}</button>`).join('');
      $$('.time-chip', times).forEach((b) => b.addEventListener('click', () => {
        state.time = b.dataset.time;
        $$('.time-chip', times).forEach((x) => {
          x.classList.toggle('selected', x === b);
          x.setAttribute('aria-selected', String(x === b));
        });
        $('#to-details').disabled = false;
      }));
      $('#times-note').textContent = `Each lesson is ${data.durationMin} minutes. Times are Windhoek time.`;
    } catch (err) {
      times.innerHTML = '';
      showAlert(err.message);
    }
  }

  $('#to-details').addEventListener('click', () => { if (state.time) goTo(4); });

  // ---------- step 4: details ----------
  const form = $('#details-form');
  const pickupInput = $('#pickupLocation');
  function syncPickup() {
    const atSchool = form.pickupType.value === 'school';
    pickupInput.hidden = atSchool;
    pickupInput.required = !atSchool;
  }
  $$('input[name="pickupType"]').forEach((r) => r.addEventListener('change', syncPickup));
  syncPickup();

  function setFieldErrors(errors) {
    $$('.field-error').forEach((p) => { p.textContent = ''; });
    $$('#details-form input').forEach((i) => i.removeAttribute('aria-invalid'));
    Object.entries(errors || {}).forEach(([name, msg]) => {
      const p = $(`.field-error[data-for="${name}"]`);
      if (p) p.textContent = msg;
      const input = document.getElementById(name);
      if (input) input.setAttribute('aria-invalid', 'true');
    });
    const firstBad = $('#details-form [aria-invalid="true"]');
    if (firstBad) firstBad.focus();
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const atSchool = form.pickupType.value === 'school';
    const d = {
      customerName: form.customerName.value.trim(),
      customerPhone: form.customerPhone.value.trim(),
      customerEmail: form.customerEmail.value.trim(),
      pickupLocation: atSchool ? 'At the school' : pickupInput.value.trim(),
      notes: form.notes.value.trim(),
    };
    const errors = {};
    if (d.customerName.length < 2) errors.customerName = 'Enter your full name.';
    if (d.customerPhone.replace(/\D/g, '').length < 9) errors.customerPhone = 'Enter your cellphone number, for example 081 234 5678.';
    if (d.customerEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.customerEmail)) errors.customerEmail = 'Check your email address or leave it empty.';
    if (!atSchool && d.pickupLocation.length < 3) errors.pickupLocation = 'Enter your pickup address, or choose "I\'ll come to the school".';
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;
    state.details = d;
    renderSummary($('#summary'));
    goTo(5);
  });

  function summaryRows() {
    const end = addMinutes(state.time, state.pkg.durationMin);
    return [
      ['Licence', `Code ${state.code}`],
      ['Package', `${state.pkg.name}${state.pkg.lessons > 1 ? ` (${state.pkg.lessons} lessons)` : ''}`],
      ['Date', formatDate(state.date)],
      ['Time', `${state.time} to ${end}`],
      ['Pickup', state.details.pickupLocation],
      ['Name', state.details.customerName],
      ['Cellphone', state.details.customerPhone],
      ['Price', money(state.pkg.price)],
    ];
  }

  function renderSummary(el) {
    el.innerHTML = summaryRows().map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('');
  }

  // ---------- step 5: confirm ----------
  $('#confirm-btn').addEventListener('click', async () => {
    const btn = $('#confirm-btn');
    btn.disabled = true;
    btn.textContent = 'Booking…';
    try {
      const { booking } = await post('/api/bookings', {
        licenseCode: state.code, packageId: state.pkg.id, lessonDate: state.date, startTime: state.time, ...state.details,
      });
      state.booking = booking;
      renderDone();
      history.replaceState({ step: 6 }, '', '#step-6');
      goTo(6, false);
    } catch (err) {
      if (err.status === 409) {
        state.time = null;
        goTo(3);
        showAlert(err.message);
        selectDate(state.date);
      } else if (err.status === 422) {
        goTo(4);
        setFieldErrors(err.fields);
        showAlert(err.message);
      } else {
        showAlert(err.message);
      }
    } finally {
      btn.disabled = false;
      btn.textContent = 'Confirm booking';
    }
  });

  // ---------- done ----------
  function renderDone() {
    const b = state.booking;
    $('#done-ref').textContent = b.reference;
    renderSummary($('#done-summary'));
    const msg = [
      `Hi ${config.SCHOOL_NAME || 'First Driving School'}, I just booked online.`,
      `Reference: ${b.reference}`,
      `Code ${b.licenseCode}, ${b.packageName}`,
      `${formatDate(b.lessonDate)} at ${b.startTime}`,
      `Name: ${b.customerName}`,
      `Pickup: ${b.pickupLocation}`,
    ].join('\n');
    $('#whatsapp-btn').href = `https://wa.me/${config.WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
    $('#calendar-btn').href = `data:text/calendar;charset=utf-8,${encodeURIComponent(buildIcs(b))}`;
  }

  function buildIcs(b) {
    // Windhoek is UTC+2 all year.
    const [y, m, d] = b.lessonDate.split('-').map(Number);
    const [hh, mm] = b.startTime.split(':').map(Number);
    const start = new Date(Date.UTC(y, m - 1, d, hh - 2, mm));
    const end = new Date(start.getTime() + b.durationMin * 60000);
    const fmt = (dt) => dt.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    return [
      'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//First Driving School//Booking//EN', 'BEGIN:VEVENT',
      `UID:${b.reference}@firstdrivingschool`, `DTSTAMP:${fmt(new Date())}`, `DTSTART:${fmt(start)}`, `DTEND:${fmt(end)}`,
      `SUMMARY:Driving lesson - Code ${b.licenseCode}`,
      `DESCRIPTION:First Driving School\\nReference ${b.reference}\\n${b.packageName}`,
      `LOCATION:${String(b.pickupLocation).replace(/[,;]/g, ' ')}`,
      'BEGIN:VALARM', 'TRIGGER:-PT1H', 'ACTION:DISPLAY', 'DESCRIPTION:Driving lesson in 1 hour', 'END:VALARM',
      'END:VEVENT', 'END:VCALENDAR',
    ].join('\r\n');
  }

  $('#again-btn').addEventListener('click', () => {
    Object.assign(state, { code: null, pkg: null, date: null, time: null, details: null, booking: null });
    form.reset();
    syncPickup();
    history.replaceState({ step: 1 }, '', '#step-1');
    goTo(1, false);
  });

  // ---------- lookup ----------
  $('#lookup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const out = $('#lookup-result');
    const ref = $('#lookupRef').value.trim().toUpperCase();
    const phone = $('#lookupPhone').value.trim();
    if (!ref || !phone) { out.innerHTML = '<p class="error-text">Enter your reference and cellphone number.</p>'; return; }
    out.innerHTML = '<p class="loading">Searching&hellip;</p>';
    try {
      const { booking: b } = await get(`/api/bookings/${encodeURIComponent(ref)}?phone=${encodeURIComponent(phone)}`);
      const statusText = { pending: 'Waiting for confirmation', confirmed: 'Confirmed', completed: 'Completed', cancelled: 'Cancelled', no_show: 'Missed' }[b.status] || b.status;
      out.innerHTML = `<dl class="summary">
        <div><dt>Status</dt><dd><span class="badge badge-${esc(b.status)}">${esc(statusText)}</span></dd></div>
        <div><dt>Lesson</dt><dd>Code ${esc(b.licenseCode)}, ${esc(b.packageName)}</dd></div>
        <div><dt>When</dt><dd>${esc(formatDate(b.lessonDate))} at ${esc(b.startTime)}</dd></div>
        ${b.instructorName ? `<div><dt>Instructor</dt><dd>${esc(b.instructorName)}</dd></div>` : ''}
      </dl>`;
    } catch (err) {
      out.innerHTML = `<p class="error-text">${esc(err.message)}</p>`;
    }
  });

  // ---------- start ----------
  if (config.PHONE_TEL) $('#call-link').href = `tel:${config.PHONE_TEL}`;
  history.replaceState({ step: 1 }, '', location.pathname + location.search);
  goTo(1, false);
  loadCatalog();
})();
