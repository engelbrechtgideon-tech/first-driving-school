/* First Driving School - service worker.
 * Raise CACHE_VERSION whenever you change any file in /public, so phones
 * with the installed app download the new version. */
const CACHE_VERSION = 'fds-v2.0.0';
const APP_SHELL = [
  './',
  './index.html',
  './staff.html',
  './offline.html',
  './config.js',
  './css/styles.css',
  './css/staff.css',
  './js/api.js',
  './js/booking.js',
  './js/staff.js',
  './js/pwa.js',
  './manifest.json',
  './manifest-staff.json',
  './favicon.svg',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Never cache the API - bookings and free times must always be live.
  if (url.pathname.includes('/api/')) return;
  // Leave other websites (e.g. Google Fonts) to the browser.
  if (url.origin !== self.location.origin) return;

  // Pages: network first, fall back to cache, then the offline page.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req, { ignoreSearch: true }).then((hit) => hit || caches.match('./offline.html'))),
    );
    return;
  }

  // Files: cache first, refresh in the background.
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => {
      const network = fetch(req)
        .then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => hit);
      return hit || network;
    }),
  );
});
