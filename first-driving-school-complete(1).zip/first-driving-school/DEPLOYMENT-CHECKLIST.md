# Deployment checklist - free online test, iPhone install, go live

Everything below uses **free** plans. No Heroku, no card for the test phase.

| Piece | Free service | Why |
|---|---|---|
| Code storage | GitHub | Render deploys from it |
| Website + API (one address, HTTPS) | Render free web service | iPhone needs HTTPS to install the app |
| Database | Neon free PostgreSQL | Keeps bookings permanently |

> Render free limits: the service sleeps after about 15 minutes without visitors and
> takes about a minute to wake up on the next visit. Fine for testing. For real
> customers you can later move to a paid Render plan (no code changes needed).
> Do **not** use Render's own free PostgreSQL - it is deleted after 30 days. Use Neon.

---

## Phase 1 - Test on your computer

- [ ] Follow **QUICK-START.md**.
- [ ] `npm test` shows `All checks passed`.
- [ ] Made a test booking at http://localhost:3000
- [ ] Saw it in the staff dashboard at http://localhost:3000/staff.html

## Phase 2 - Put the code on GitHub (free)

- [ ] Create an account at https://github.com
- [ ] New repository > name `first-driving-school` > **Private** > Create.
- [ ] Upload the project: "uploading an existing file" > drag in all files and folders
      from the unzipped folder **except** `node_modules`, `data` and `.env`.
      (If you use Git: `git init`, `git add .`, `git commit -m "v2"`, then push. The
      `.gitignore` already keeps those out.)
- [ ] Check `.env` is **not** in the repository. Secrets go into Render, never GitHub.

## Phase 3 - Free database on Neon

- [ ] Sign up at https://neon.tech (free plan).
- [ ] Create project > name `first-driving-school` > region closest to you
      (Europe - Frankfurt is usually closest to Namibia).
- [ ] Dashboard > **Connect** > copy the connection string. It looks like:
      `postgresql://user:password@ep-xxxx.eu-central-1.aws.neon.tech/neondb?sslmode=require`
- [ ] Keep it private - it contains the database password.

You do not need to create tables. The server creates them on first start
(`AUTO_MIGRATE=true`).

## Phase 4 - Website + API on Render (free)

- [ ] Sign up at https://render.com with your GitHub account.
- [ ] **New > Blueprint** > choose the `first-driving-school` repository.
      Render reads `render.yaml` and sets up one free web service.
- [ ] When asked, fill in:
  - `DATABASE_URL` = the Neon connection string from Phase 3
  - `ADMIN_EMAIL` = your staff login email
  - `ADMIN_PASSWORD` = at least 8 characters (you will change it after login)
  - `JWT_SECRET` is generated automatically.
- [ ] Click **Apply**. Wait for the log to show `First Driving School is running` (a few minutes).
- [ ] Open `https://<your-service>.onrender.com/api/health` - you should see
      `"ok":true` and `"database":"postgres"`.
      If it says `json`, `DATABASE_URL` is missing - fix it under Environment.

No Blueprint? Use **New > Web Service** instead: build command `npm install`,
start command `npm start`, instance type **Free**, then add the environment
variables from `.env.example` by hand (`NODE_ENV=production`, `JWT_SECRET`, etc).

## Phase 5 - First login and set up the school

Open `https://<your-service>.onrender.com/staff.html`

- [ ] Log in with `ADMIN_EMAIL` / `ADMIN_PASSWORD`.
- [ ] **My account** > change password.
- [ ] **Packages** > set your real prices (the starting prices are EXAMPLES).
      Hide packages you do not offer.
- [ ] **Instructors** > check names, phone numbers and which codes each one teaches.
- [ ] **Schedule** > opening hours, lesson length, booking window, minimum notice.
- [ ] **Schedule > Time off** > public holidays and instructor leave.
- [ ] **My account > Add staff login** (admins only) > add other staff if needed.
- [ ] Make a test booking on the main page, confirm it in the dashboard, then cancel it.

## Phase 6 - Test the app on an iPhone

Must use the **https://** Render address. Install does not work on `http://`.

- [ ] Open the Render address in **Safari** (not Chrome - on iPhone only Safari
      can add web apps to the Home Screen reliably).
- [ ] Tap **Share** (square with arrow) > **Add to Home Screen** > **Add**.
- [ ] Yellow-and-black icon appears on the Home Screen with the name "First Driving".
- [ ] Open it from the icon: no Safari address bar (full-screen app).
- [ ] Complete a booking from start to finish in the app.
- [ ] "Send on WhatsApp" opens WhatsApp with the booking details.
- [ ] "Add to calendar" adds the lesson to the iPhone calendar.
- [ ] Turn on Airplane mode, reopen the app: the offline page appears
      (not an error). Turn Airplane mode off, tap "Try again".
- [ ] Staff: open `.../staff.html` in Safari > Share > Add to Home Screen gives a
      separate "FDS Staff" icon.

If the icon or changes look old: delete the icon from the Home Screen, open the
site in Safari once, then add it again.

## Phase 7 - Go live

- [ ] Optional custom domain (e.g. `book.firstdrivingschool.com.na`):
      Render > Settings > Custom Domains, then add the DNS record Render shows you
      at your domain provider. HTTPS is free and automatic.
- [ ] Make a QR code that points to the booking address (any free QR generator)
      for flyers, cars and the office.
- [ ] Add the booking link to Google Business Profile, Facebook and WhatsApp Business.
- [ ] Decide if the free sleep delay is OK. If customers complain the first load is
      slow, upgrade the Render service to a paid instance (same code, same settings).

## Phase 8 - Optional: host the frontend somewhere else

Only needed if you want the website on Netlify, GitHub Pages or your own web host
while the API stays on Render.

- [ ] Upload **only** the `public/` folder to the frontend host.
- [ ] Edit `public/config.js`:
      `API_BASE_URL: 'https://<your-service>.onrender.com'` (no slash at the end).
- [ ] On Render add `ALLOWED_ORIGINS=https://<your-frontend-address>`
      (comma-separated if more than one) and redeploy.
- [ ] Raise `CACHE_VERSION` in `public/service-worker.js` (e.g. `fds-v2.0.1`).
- [ ] Test a booking and a staff login from the new address.

## Phase 9 - Updating and looking after it

- [ ] After changing any file in `public/`, raise `CACHE_VERSION` in
      `public/service-worker.js`, so installed apps download the new version.
- [ ] Run `npm test` before every upload.
- [ ] Push to GitHub - Render redeploys automatically.
- [ ] Backups: Neon keeps restore history on the free plan; for extra safety export
      now and then with `pg_dump "<DATABASE_URL>" > backup.sql`.
- [ ] If you ever change `JWT_SECRET`, all staff simply have to log in again.

---

## Optional: HTTPS from your own computer (no hosting at all)

To try the iPhone install before using Render, a free Cloudflare quick tunnel gives
your computer a temporary https address:

```bash
npm start
# in a second window (install cloudflared from developers.cloudflare.com first):
cloudflared tunnel --url http://localhost:3000
```

Open the `https://....trycloudflare.com` address it prints on your iPhone in Safari
and follow Phase 6. The address changes every time, so use it only for testing.
