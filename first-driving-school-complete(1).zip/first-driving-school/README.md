# First Driving School - booking system v2 (technical reference)

Online lesson booking for First Driving School, Windhoek: customer booking website,
staff dashboard, JSON API and installable PWA, served by one Node.js process.

New here? Read **START-HERE.md** first, then **QUICK-START.md** and **DEPLOYMENT-CHECKLIST.md**.

## Requirements

- Node.js 20.12 or newer (22 LTS recommended)
- Optional: PostgreSQL 13+ (Neon free plan recommended). Without it a JSON test store is used.
- Only runtime dependency: `pg` (loaded only when `DATABASE_URL` is set)

## Scripts

| Command | What it does |
|---|---|
| `npm start` | Start the server (`backend-server.js`) |
| `npm run dev` | Start with auto-restart on file changes |
| `npm run migrate` | Create tables and starter data (`scripts/migrate.js`). Also runs on start when `AUTO_MIGRATE=true` |
| `npm run check` | Verify every referenced file exists (`scripts/check-project.js`) |
| `npm test` | `check` + 35 end-to-end API/PWA tests on a temporary database (`scripts/smoke-test.js`) |

## Folder structure

```
backend-server.js        HTTP server: static files, /api routes, security headers, CORS
package.json  .env.example  render.yaml
src/
  config.js              Reads environment variables, validates production settings
  http.js                Router, JSON body parser, errors, rate limiter
  auth.js                scrypt password hashing, signed session tokens (HS256)
  license-codes.js       Codes B, A1, C1, C1E
  db/
    index.js             Picks PostgreSQL or JSON store, runs migration + seeding
    postgres-store.js    PostgreSQL implementation
    json-store.js        JSON-file implementation (local testing only)
    schema.sql           Tables and indexes
    seed-data.js         Starter schedule, instructors, example packages
  services/
    time.js              Africa/Windhoek date/time helpers
    availability.js      Free slots from hours, lesson length, bookings, time off
    bookings.js          Create / reschedule / status changes, instructor assignment
  routes/
    public.js            Customer API
    staff.js             Staff API (login required)
scripts/
  migrate.js  check-project.js  smoke-test.js
public/                  Everything the browser loads
  index.html             Booking website (PWA start page)
  staff.html             Staff dashboard
  offline.html  404.html
  config.js              Frontend settings (API_BASE_URL, phone, WhatsApp, currency)
  manifest.json          Customer PWA manifest
  manifest-staff.json    Staff PWA manifest
  service-worker.js      Offline app shell; never caches /api
  css/  js/  icons/  favicon.svg
```

## Environment variables

See `.env.example` for full comments.

| Variable | Default | Notes |
|---|---|---|
| `NODE_ENV` | `development` | `production` on the live server |
| `PORT` | `3000` | Set automatically by Render |
| `DATABASE_URL` | empty | PostgreSQL connection string. Empty = JSON test store |
| `DATABASE_SSL` | `true` | `false` only for local PostgreSQL without SSL |
| `DATA_FILE` | `./data/dev-db.json` | JSON store location |
| `AUTO_MIGRATE` | `true` | Create tables + starter data on start |
| `JWT_SECRET` | empty | Required in production, 32+ characters |
| `SESSION_HOURS` | `12` | Staff login lifetime |
| `ADMIN_EMAIL` / `ADMIN_NAME` / `ADMIN_PASSWORD` | - | First admin, created only when no staff exist. No default password in production |
| `ALLOWED_ORIGINS` | empty | Only when the frontend is hosted on another domain |
| `TRUST_PROXY` | `true` | Use `X-Forwarded-For` for rate limiting behind Render etc. |
| `TIMEZONE` | `Africa/Windhoek` | Business time zone |

## Changing the API URL

The frontend reads `public/config.js`:

- `API_BASE_URL: ''` - API on the same address as the website (default: local and Render).
- `API_BASE_URL: 'https://your-api.onrender.com'` - frontend hosted elsewhere. Also set
  `ALLOWED_ORIGINS` on the backend to the frontend's address.

After any change in `public/`, raise `CACHE_VERSION` in `public/service-worker.js`.

## API

All responses are JSON. Errors: `{ "error": "message" }` with 400/401/403/404/409/422/429/500.

**Public**

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | `{ ok, database, time }` |
| GET | `/api/catalog` | Licence codes, active packages, booking rules |
| GET | `/api/availability/days?code=B&packageId=..` | Days with free slots in the booking window |
| GET | `/api/availability?code=B&packageId=..&date=YYYY-MM-DD` | Free start times on a day |
| POST | `/api/bookings` | Create booking, returns reference `FDS-XXXXXX` |
| GET | `/api/bookings/:reference?phone=<last 4 digits>` | Customer booking lookup |

**Staff** (header `Authorization: Bearer <token>`)

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/auth/login` | Email + password > token |
| GET | `/api/auth/me` | Current user |
| POST | `/api/auth/change-password` | Change own password |
| POST | `/api/staff/users` | Add staff login (admin only) |
| GET | `/api/staff/stats` | Today, pending and upcoming counts, this month's booked value |
| GET, POST | `/api/staff/bookings` | List (filters: date range, status, instructor, search) / phone-in booking |
| GET, PATCH | `/api/staff/bookings/:id` | Details / status, reschedule, instructor, notes |
| GET | `/api/staff/availability` | Free slots for staff (reschedule, phone-in) |
| GET, POST | `/api/staff/instructors` | List / add |
| PATCH, DELETE | `/api/staff/instructors/:id` | Edit / remove (deactivated if they have bookings) |
| GET, PUT | `/api/staff/schedule` | Opening hours, lesson length, booking window, notice |
| GET, POST | `/api/staff/time-off` | List / add closed day or instructor leave |
| DELETE | `/api/staff/time-off/:id` | Remove time off |
| GET, POST | `/api/staff/packages` | List / add package |
| PATCH | `/api/staff/packages/:id` | Edit price, name, lessons, hide/show |

## Data model

Tables (`src/db/schema.sql`): `staff_users`, `instructors`, `packages`, `settings`
(schedule JSON), `time_off`, `bookings`. Booking statuses: `pending`, `confirmed`,
`completed`, `cancelled`, `no_show`. A partial unique index on
(instructor, start time) for active bookings blocks double booking at database level,
in addition to an in-process lock.

## Booking rules

- Slots follow the weekly hours (default Mon-Fri 07:00-17:00, Sat 08:00-13:00, Sun closed).
- Bookable from the minimum notice (default 12 h) up to the booking window (default 30 days).
- An instructor must teach the chosen code; the least busy free instructor is assigned.
- School-wide or instructor time off (full or part day) removes slots.

## Security

- No secrets in the code or frontend. Secrets live in `.env` (git-ignored) or host settings.
- Passwords hashed with scrypt; sessions are signed tokens that expire.
- Login rate limit 10 per 15 min, bookings 20 per hour per IP.
- Security headers + Content-Security-Policy on every response.
- Production refuses to start without a 32+ character `JWT_SECRET`, never creates a
  default admin (only from `ADMIN_PASSWORD`, 8+ characters), and warns loudly if it
  would use the JSON store.

## Testing status

- `npm test` passes (reference check + 35 end-to-end checks) using the JSON store.
- The PostgreSQL store uses the same interface and schema, but was not run against a
  live PostgreSQL server during this build. Verify on Neon: `/api/health` should report
  `"database":"postgres"`, then make and manage a test booking.
