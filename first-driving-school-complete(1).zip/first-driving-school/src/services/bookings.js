'use strict';
/** Booking rules: validation, instructor auto-assignment, double-booking protection, rescheduling. */
const crypto = require('crypto');
const { HttpError } = require('../http');
const LICENSE_CODES = require('../license-codes');
const T = require('./time');
const { loadContext, computeDay, ACTIVE_STATUSES } = require('./availability');

const STATUSES = ['pending', 'confirmed', 'completed', 'cancelled', 'no_show'];
const REF_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// Serialise booking writes inside this process so two customers cannot grab the same slot.
let chain = Promise.resolve();
function withLock(fn) {
  const run = chain.then(fn, fn);
  chain = run.catch(() => {});
  return run;
}

function newReference() {
  const bytes = crypto.randomBytes(6);
  let s = 'FDS-';
  for (const b of bytes) s += REF_CHARS[b % REF_CHARS.length];
  return s;
}

const str = (v, max) => String(v ?? '').trim().slice(0, max);

function validateCustomer(input, errors) {
  const out = {
    customerName: str(input.customerName, 80),
    customerPhone: str(input.customerPhone, 25),
    customerEmail: str(input.customerEmail, 120).toLowerCase(),
    pickupLocation: str(input.pickupLocation, 200),
    notes: str(input.notes, 500),
  };
  if (out.customerName.length < 2) errors.customerName = 'Enter your full name.';
  const digits = out.customerPhone.replace(/\D/g, '');
  if (!/^[+\d][\d\s()-]*$/.test(out.customerPhone) || digits.length < 9 || digits.length > 15) {
    errors.customerPhone = 'Enter a valid phone number, for example 081 234 5678.';
  }
  if (out.customerEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(out.customerEmail)) errors.customerEmail = 'Enter a valid email address or leave it empty.';
  return out;
}

function pickInstructor(freeIds, dayBookings) {
  const load = (id) => dayBookings.filter((b) => b.instructorId === id).length;
  return [...freeIds].sort((a, b) => load(a) - load(b) || a - b)[0];
}

/**
 * Creates a booking.
 * @param opts.staff  true when a staff member books (ignores notice/booking window, may choose instructor/status)
 */
async function createBooking(db, input, { staff = false } = {}) {
  const errors = {};
  const licenseCode = str(input.licenseCode, 5).toUpperCase();
  if (!LICENSE_CODES.some((c) => c.code === licenseCode)) errors.licenseCode = 'Choose a licence code.';
  const lessonDate = str(input.lessonDate, 10);
  const startTime = str(input.startTime, 5);
  if (!T.isValidDate(lessonDate)) errors.lessonDate = 'Choose a date.';
  if (!T.isValidTime(startTime)) errors.startTime = 'Choose a time.';
  const customer = validateCustomer(input, errors);

  const pkg = Number.isInteger(Number(input.packageId)) ? await db.getPackage(Number(input.packageId)) : null;
  if (!pkg || (!pkg.active && !staff)) errors.packageId = 'Choose a package.';
  else if (pkg.code !== licenseCode) errors.packageId = 'This package is not available for the chosen licence code.';

  let status = 'pending';
  if (staff && input.status !== undefined) {
    if (!STATUSES.includes(input.status)) errors.status = 'Unknown status.';
    else status = input.status;
  } else if (staff) status = 'confirmed';

  if (Object.keys(errors).length) throw new HttpError(422, 'Please check the highlighted fields.', errors);

  return withLock(async () => {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const ctx = await loadContext(db, lessonDate, lessonDate);
      const day = computeDay(ctx, { date: lessonDate, code: licenseCode, durationMin: pkg.durationMin, staff });
      const slot = day.slots.find((s) => s.time === startTime);
      if (!slot || !slot.available) throw new HttpError(409, 'Sorry, that time has just been taken. Please choose another time.');

      let instructorId;
      if (staff && input.instructorId) {
        instructorId = Number(input.instructorId);
        if (!slot.freeInstructorIds.includes(instructorId)) throw new HttpError(409, 'That instructor is not free at this time or does not teach this code.');
      } else {
        instructorId = pickInstructor(slot.freeInstructorIds, ctx.bookings.filter((b) => b.lessonDate === lessonDate));
      }

      try {
        return await db.createBooking({
          reference: newReference(), licenseCode, packageId: pkg.id, packageName: pkg.name, price: pkg.price,
          lessonDate, startTime, durationMin: pkg.durationMin, instructorId, status,
          staffNotes: staff ? str(input.staffNotes, 1000) : '', ...customer,
        });
      } catch (err) {
        if (err.code !== 'DUPLICATE') throw err; // reference clash or slot taken - try again
      }
    }
    throw new HttpError(409, 'Sorry, that time has just been taken. Please choose another time.');
  });
}

/** Staff update: status, notes, reschedule, change instructor, customer details. */
async function updateBooking(db, id, input) {
  const booking = await db.getBookingById(id);
  if (!booking) throw new HttpError(404, 'Booking not found.');
  const errors = {};
  const patch = {};

  if (input.status !== undefined) {
    if (!STATUSES.includes(input.status)) errors.status = 'Unknown status.';
    else patch.status = input.status;
  }
  if (input.staffNotes !== undefined) patch.staffNotes = str(input.staffNotes, 1000);
  for (const k of ['customerName', 'customerPhone', 'customerEmail', 'pickupLocation', 'notes']) {
    if (input[k] !== undefined) patch[k] = k === 'customerEmail' ? str(input[k], 120).toLowerCase() : str(input[k], k === 'notes' ? 500 : 200);
  }
  if (patch.customerName !== undefined && patch.customerName.length < 2) errors.customerName = 'Enter a name.';
  if (input.lessonDate !== undefined) {
    if (!T.isValidDate(input.lessonDate)) errors.lessonDate = 'Invalid date.'; else patch.lessonDate = input.lessonDate;
  }
  if (input.startTime !== undefined) {
    if (!T.isValidTime(input.startTime)) errors.startTime = 'Invalid time.'; else patch.startTime = input.startTime;
  }
  if (input.instructorId !== undefined) patch.instructorId = input.instructorId ? Number(input.instructorId) : null;
  if (Object.keys(errors).length) throw new HttpError(422, 'Please check the highlighted fields.', errors);

  const next = { ...booking, ...patch };
  const moving = next.lessonDate !== booking.lessonDate || next.startTime !== booking.startTime || next.instructorId !== booking.instructorId;
  const becomesActive = ACTIVE_STATUSES.includes(next.status) && !ACTIVE_STATUSES.includes(booking.status);

  return withLock(async () => {
    if (ACTIVE_STATUSES.includes(next.status) && (moving || becomesActive)) {
      const ctx = await loadContext(db, next.lessonDate, next.lessonDate);
      const day = computeDay(ctx, { date: next.lessonDate, code: booking.licenseCode, durationMin: booking.durationMin, staff: true, excludeBookingId: booking.id });
      const slot = day.slots.find((s) => s.time === next.startTime);
      if (!slot || !slot.available) throw new HttpError(409, 'No instructor is free at that time. Choose another time.');
      if (input.instructorId) {
        if (!slot.freeInstructorIds.includes(next.instructorId)) throw new HttpError(409, 'That instructor is busy or off at that time.');
      } else if (!slot.freeInstructorIds.includes(next.instructorId)) {
        patch.instructorId = pickInstructor(slot.freeInstructorIds, ctx.bookings.filter((b) => b.lessonDate === next.lessonDate));
      }
    }
    try {
      return await db.updateBooking(booking.id, patch);
    } catch (err) {
      if (err.code === 'DUPLICATE') throw new HttpError(409, 'That instructor already has a lesson at this time.');
      throw err;
    }
  });
}

module.exports = { createBooking, updateBooking, STATUSES };
