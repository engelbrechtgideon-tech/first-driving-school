'use strict';
/**
 * Works out which lesson times are free.
 * A time is free when at least one active instructor who teaches the licence code
 * has no overlapping booking or time off, and the school is open.
 */
const config = require('../config');
const T = require('./time');

const ACTIVE_STATUSES = ['pending', 'confirmed'];

async function loadContext(db, from, to) {
  const [schedule, instructors, bookings, timeOff] = await Promise.all([
    db.getSetting('schedule'),
    db.listInstructors({ activeOnly: true }),
    db.listBookings({ from, to, status: ACTIVE_STATUSES }),
    db.listTimeOff({ from, to }),
  ]);
  return { schedule, instructors, bookings, timeOff, now: T.nowIn(config.timezone) };
}

/**
 * @param ctx      result of loadContext
 * @param opts     { date, code, durationMin, staff (bool: ignore notice/window), excludeBookingId }
 */
function computeDay(ctx, { date, code, durationMin, staff = false, excludeBookingId = null }) {
  const { schedule, now } = ctx;
  const result = { date, open: false, reason: '', slots: [] };

  if (!staff) {
    if (date < now.date) { result.reason = 'past'; return result; }
    if (date > T.addDays(now.date, schedule.bookingWindowDays)) { result.reason = 'too_far'; return result; }
  }
  const hours = schedule.hours[String(T.weekday(date))] || schedule.hours[T.weekday(date)];
  if (!hours) { result.reason = 'closed'; return result; }

  const dayOff = ctx.timeOff.filter((t) => t.date === date);
  const schoolOff = dayOff.filter((t) => t.instructorId === null || t.instructorId === undefined);
  if (schoolOff.some((t) => !t.startTime)) { result.reason = 'closed'; return result; }

  const candidates = ctx.instructors.filter((i) => i.codes.includes(code));
  if (!candidates.length) { result.reason = 'no_instructor'; return result; }

  // Earliest bookable moment for customers (now + minimum notice).
  const noticeTotal = now.minutes + (schedule.minNoticeHours || 0) * 60;
  const earliestDate = T.addDays(now.date, Math.floor(noticeTotal / 1440));
  const earliestMin = noticeTotal % 1440;

  const dayBookings = ctx.bookings.filter((b) => b.lessonDate === date && ACTIVE_STATUSES.includes(b.status) && b.id !== excludeBookingId);
  const open = T.toMin(hours.open);
  const close = T.toMin(hours.close);
  const step = schedule.slotMinutes || 60;

  result.open = true;
  for (let start = open; start + durationMin <= close; start += step) {
    const end = start + durationMin;
    const time = T.fromMin(start);
    let available = true;
    if (!staff && (date < earliestDate || (date === earliestDate && start < earliestMin))) available = false;
    if (available && schoolOff.some((t) => T.overlaps(start, end, T.toMin(t.startTime), T.toMin(t.endTime)))) available = false;

    const free = available ? candidates.filter((ins) => {
      const busy = dayBookings.some((b) => b.instructorId === ins.id && T.overlaps(start, end, T.toMin(b.startTime), T.toMin(b.startTime) + b.durationMin));
      if (busy) return false;
      return !dayOff.some((t) => t.instructorId === ins.id && (!t.startTime || T.overlaps(start, end, T.toMin(t.startTime), T.toMin(t.endTime))));
    }).map((i) => i.id) : [];

    result.slots.push({ time, available: free.length > 0, freeInstructorIds: free });
  }
  if (!result.slots.some((s) => s.available)) result.reason = 'full';
  return result;
}

module.exports = { loadContext, computeDay, ACTIVE_STATUSES };
