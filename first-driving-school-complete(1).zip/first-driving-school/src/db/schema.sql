-- First Driving School - PostgreSQL schema.
-- Safe to run many times (everything uses IF NOT EXISTS).

CREATE TABLE IF NOT EXISTS staff_users (
  id            SERIAL PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'staff' CHECK (role IN ('admin', 'staff')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS instructors (
  id         SERIAL PRIMARY KEY,
  name       TEXT NOT NULL,
  phone      TEXT NOT NULL DEFAULT '',
  codes      TEXT[] NOT NULL DEFAULT '{}',
  active     BOOLEAN NOT NULL DEFAULT TRUE,
  notes      TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS packages (
  id           SERIAL PRIMARY KEY,
  code         TEXT NOT NULL,
  name         TEXT NOT NULL,
  description  TEXT NOT NULL DEFAULT '',
  lessons      INTEGER NOT NULL DEFAULT 1 CHECK (lessons > 0),
  duration_min INTEGER NOT NULL DEFAULT 60 CHECK (duration_min > 0),
  price        NUMERIC(10,2) NOT NULL DEFAULT 0,
  active       BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS time_off (
  id            SERIAL PRIMARY KEY,
  instructor_id INTEGER REFERENCES instructors(id) ON DELETE CASCADE,  -- NULL = whole school closed
  date          DATE NOT NULL,
  start_time    TEXT,   -- 'HH:MM' or NULL for the whole day
  end_time      TEXT,
  reason        TEXT NOT NULL DEFAULT '',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS time_off_date_idx ON time_off (date);

CREATE TABLE IF NOT EXISTS bookings (
  id              SERIAL PRIMARY KEY,
  reference       TEXT NOT NULL UNIQUE,
  license_code    TEXT NOT NULL,
  package_id      INTEGER REFERENCES packages(id) ON DELETE SET NULL,
  package_name    TEXT NOT NULL,
  price           NUMERIC(10,2) NOT NULL DEFAULT 0,
  lesson_date     DATE NOT NULL,
  start_time      TEXT NOT NULL,          -- 'HH:MM'
  duration_min    INTEGER NOT NULL DEFAULT 60,
  instructor_id   INTEGER REFERENCES instructors(id) ON DELETE SET NULL,
  customer_name   TEXT NOT NULL,
  customer_phone  TEXT NOT NULL,
  customer_email  TEXT NOT NULL DEFAULT '',
  pickup_location TEXT NOT NULL DEFAULT '',
  notes           TEXT NOT NULL DEFAULT '',
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled', 'no_show')),
  staff_notes     TEXT NOT NULL DEFAULT '',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS bookings_date_idx ON bookings (lesson_date);
CREATE INDEX IF NOT EXISTS bookings_instructor_idx ON bookings (instructor_id);
-- An instructor cannot have two active bookings starting at the same time.
CREATE UNIQUE INDEX IF NOT EXISTS bookings_no_double_booking
  ON bookings (instructor_id, lesson_date, start_time)
  WHERE status IN ('pending', 'confirmed');
