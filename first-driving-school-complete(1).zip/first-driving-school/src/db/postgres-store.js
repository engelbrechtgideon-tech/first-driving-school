'use strict';
/**
 * PostgreSQL database (used when DATABASE_URL is set). Works with Neon, Supabase,
 * Render Postgres, Railway, or your own PostgreSQL server.
 */
const fs = require('fs');
const path = require('path');

function createPostgresStore({ connectionString, ssl }) {
  let pg;
  try {
    pg = require('pg');
  } catch {
    throw new Error('The "pg" package is missing. Run "npm install" first.');
  }
  // Return DATE columns as 'YYYY-MM-DD' strings and NUMERIC as numbers.
  pg.types.setTypeParser(1082, (v) => v);
  pg.types.setTypeParser(1700, (v) => (v === null ? null : parseFloat(v)));

  const isLocal = /@(localhost|127\.0\.0\.1)(:|\/)/.test(connectionString);
  const pool = new pg.Pool({
    connectionString,
    ssl: ssl && !isLocal ? { rejectUnauthorized: false } : false,
    max: 5,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 15_000,
  });
  pool.on('error', (err) => console.error('[db] idle client error:', err.message));

  const q = (text, params) => pool.query(text, params);
  const one = async (text, params) => (await q(text, params)).rows[0] || null;

  const iso = (v) => (v instanceof Date ? v.toISOString() : v);
  const mapStaff = (r) => r && { id: r.id, email: r.email, name: r.name, passwordHash: r.password_hash, role: r.role, createdAt: iso(r.created_at) };
  const mapInstructor = (r) => r && { id: r.id, name: r.name, phone: r.phone, codes: r.codes || [], active: r.active, notes: r.notes, createdAt: iso(r.created_at) };
  const mapPackage = (r) => r && { id: r.id, code: r.code, name: r.name, description: r.description, lessons: r.lessons, durationMin: r.duration_min, price: Number(r.price), active: r.active, sortOrder: r.sort_order };
  const mapTimeOff = (r) => r && { id: r.id, instructorId: r.instructor_id, date: r.date, startTime: r.start_time, endTime: r.end_time, reason: r.reason, createdAt: iso(r.created_at) };
  const mapBooking = (r) => r && {
    id: r.id, reference: r.reference, licenseCode: r.license_code, packageId: r.package_id, packageName: r.package_name,
    price: Number(r.price), lessonDate: r.lesson_date, startTime: r.start_time, durationMin: r.duration_min,
    instructorId: r.instructor_id, customerName: r.customer_name, customerPhone: r.customer_phone,
    customerEmail: r.customer_email, pickupLocation: r.pickup_location, notes: r.notes, status: r.status,
    staffNotes: r.staff_notes, createdAt: iso(r.created_at), updatedAt: iso(r.updated_at),
  };

  /** Builds "UPDATE ... SET a=$1, b=$2 WHERE id=$n RETURNING *" from a whitelist. */
  async function patchRow(table, id, patch, columns, extraSet = '') {
    const sets = [];
    const values = [];
    for (const [key, col] of Object.entries(columns)) {
      if (patch[key] !== undefined) {
        values.push(patch[key]);
        sets.push(`${col} = $${values.length}`);
      }
    }
    if (!sets.length) return one(`SELECT * FROM ${table} WHERE id = $1`, [id]);
    if (extraSet) sets.push(extraSet);
    values.push(id);
    return one(`UPDATE ${table} SET ${sets.join(', ')} WHERE id = $${values.length} RETURNING *`, values);
  }

  const translateDup = (err) => {
    if (err && err.code === '23505') { const e = new Error('duplicate'); e.code = 'DUPLICATE'; return e; }
    return err;
  };

  return {
    kind: 'postgres',
    async init() {
      const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
      await q(sql);
    },
    async close() { await pool.end(); },

    // ---- staff ----
    async countStaff() { return Number((await one('SELECT count(*)::int AS n FROM staff_users')).n); },
    async getStaffByEmail(email) { return mapStaff(await one('SELECT * FROM staff_users WHERE email = $1', [String(email).toLowerCase()])); },
    async getStaffById(id) {
      if (!Number.isInteger(Number(id))) return null;
      return mapStaff(await one('SELECT * FROM staff_users WHERE id = $1', [Number(id)]));
    },
    async createStaff({ email, name, passwordHash, role }) {
      return mapStaff(await one('INSERT INTO staff_users (email, name, password_hash, role) VALUES ($1,$2,$3,$4) RETURNING *',
        [email.toLowerCase(), name, passwordHash, role || 'staff']));
    },
    async updateStaffPassword(id, passwordHash) {
      return mapStaff(await one('UPDATE staff_users SET password_hash = $1 WHERE id = $2 RETURNING *', [passwordHash, id]));
    },

    // ---- instructors ----
    async countInstructors() { return Number((await one('SELECT count(*)::int AS n FROM instructors')).n); },
    async listInstructors({ activeOnly } = {}) {
      const rows = (await q(`SELECT * FROM instructors ${activeOnly ? 'WHERE active' : ''} ORDER BY name`)).rows;
      return rows.map(mapInstructor);
    },
    async getInstructor(id) { return mapInstructor(await one('SELECT * FROM instructors WHERE id = $1', [id])); },
    async createInstructor(i) {
      return mapInstructor(await one('INSERT INTO instructors (name, phone, codes, active, notes) VALUES ($1,$2,$3,$4,$5) RETURNING *',
        [i.name, i.phone || '', i.codes || [], i.active !== false, i.notes || '']));
    },
    async updateInstructor(id, patch) {
      return mapInstructor(await patchRow('instructors', id, patch, { name: 'name', phone: 'phone', codes: 'codes', active: 'active', notes: 'notes' }));
    },
    async deleteInstructor(id) { return (await q('DELETE FROM instructors WHERE id = $1', [id])).rowCount > 0; },

    // ---- packages ----
    async countPackages() { return Number((await one('SELECT count(*)::int AS n FROM packages')).n); },
    async listPackages({ activeOnly, code } = {}) {
      const where = [];
      const vals = [];
      if (activeOnly) where.push('active');
      if (code) { vals.push(code); where.push(`code = $${vals.length}`); }
      const rows = (await q(`SELECT * FROM packages ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY code, sort_order, id`, vals)).rows;
      return rows.map(mapPackage);
    },
    async getPackage(id) { return mapPackage(await one('SELECT * FROM packages WHERE id = $1', [id])); },
    async createPackage(p) {
      return mapPackage(await one(
        'INSERT INTO packages (code, name, description, lessons, duration_min, price, active, sort_order) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
        [p.code, p.name, p.description || '', p.lessons || 1, p.durationMin || 60, Number(p.price) || 0, p.active !== false, p.sortOrder || 0]));
    },
    async updatePackage(id, patch) {
      return mapPackage(await patchRow('packages', id, patch, {
        code: 'code', name: 'name', description: 'description', lessons: 'lessons', durationMin: 'duration_min',
        price: 'price', active: 'active', sortOrder: 'sort_order',
      }));
    },

    // ---- settings ----
    async getSetting(key) { const r = await one('SELECT value FROM settings WHERE key = $1', [key]); return r ? r.value : null; },
    async setSetting(key, value) {
      await q('INSERT INTO settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value', [key, JSON.stringify(value)]);
      return value;
    },

    // ---- time off ----
    async listTimeOff({ from, to } = {}) {
      const where = [];
      const vals = [];
      if (from) { vals.push(from); where.push(`date >= $${vals.length}`); }
      if (to) { vals.push(to); where.push(`date <= $${vals.length}`); }
      const rows = (await q(`SELECT * FROM time_off ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY date, id`, vals)).rows;
      return rows.map(mapTimeOff);
    },
    async createTimeOff(t) {
      return mapTimeOff(await one('INSERT INTO time_off (instructor_id, date, start_time, end_time, reason) VALUES ($1,$2,$3,$4,$5) RETURNING *',
        [t.instructorId ?? null, t.date, t.startTime || null, t.endTime || null, t.reason || '']));
    },
    async deleteTimeOff(id) { return (await q('DELETE FROM time_off WHERE id = $1', [id])).rowCount > 0; },

    // ---- bookings ----
    async listBookings({ from, to, date, status, instructorId, q: search, limit } = {}) {
      const where = [];
      const vals = [];
      const add = (sql, v) => { vals.push(v); const ph = `$${vals.length}`; where.push(sql.replace(/\?/g, () => ph)); };
      if (date) add('lesson_date = ?', date);
      if (from) add('lesson_date >= ?', from);
      if (to) add('lesson_date <= ?', to);
      if (status) add('status = ANY(?)', [].concat(status));
      if (instructorId) add('instructor_id = ?', Number(instructorId));
      if (search) add('(reference ILIKE ? OR customer_name ILIKE ? OR customer_phone ILIKE ? OR customer_email ILIKE ?)', `%${search}%`);
      const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
      const lim = limit ? `LIMIT ${Math.min(Number(limit) || 500, 2000)}` : '';
      const sql = `SELECT * FROM bookings ${whereSql} ORDER BY lesson_date, start_time, id ${lim}`;
      return (await q(sql, vals)).rows.map(mapBooking);
    },
    async getBookingById(id) { return mapBooking(await one('SELECT * FROM bookings WHERE id = $1', [id])); },
    async getBookingByReference(ref) { return mapBooking(await one('SELECT * FROM bookings WHERE reference = $1', [String(ref).toUpperCase()])); },
    async createBooking(b) {
      try {
        return mapBooking(await one(
          `INSERT INTO bookings (reference, license_code, package_id, package_name, price, lesson_date, start_time, duration_min,
             instructor_id, customer_name, customer_phone, customer_email, pickup_location, notes, status, staff_notes)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
          [b.reference, b.licenseCode, b.packageId ?? null, b.packageName, Number(b.price) || 0, b.lessonDate, b.startTime, b.durationMin,
            b.instructorId ?? null, b.customerName, b.customerPhone, b.customerEmail || '', b.pickupLocation || '', b.notes || '',
            b.status || 'pending', b.staffNotes || '']));
      } catch (err) {
        throw translateDup(err);
      }
    },
    async updateBooking(id, patch) {
      try {
        return mapBooking(await patchRow('bookings', id, patch, {
          status: 'status', instructorId: 'instructor_id', lessonDate: 'lesson_date', startTime: 'start_time',
          durationMin: 'duration_min', staffNotes: 'staff_notes', customerName: 'customer_name', customerPhone: 'customer_phone',
          customerEmail: 'customer_email', pickupLocation: 'pickup_location', notes: 'notes',
        }, 'updated_at = now()'));
      } catch (err) {
        throw translateDup(err);
      }
    },
    async countBookingsForInstructor(id) { return Number((await one('SELECT count(*)::int AS n FROM bookings WHERE instructor_id = $1', [id])).n); },
  };
}

module.exports = { createPostgresStore };
