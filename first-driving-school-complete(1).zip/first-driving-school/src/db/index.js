'use strict';
/**
 * Chooses the database:
 *   DATABASE_URL set   -> PostgreSQL (production)
 *   DATABASE_URL empty -> JSON file   (free local testing)
 * and provides migrate(): create tables + insert starter data when empty.
 */
const config = require('../config');
const { createJsonStore } = require('./json-store');
const { createPostgresStore } = require('./postgres-store');
const seed = require('./seed-data');
const { hashPassword } = require('../auth');

function createStore() {
  if (config.databaseUrl) {
    return createPostgresStore({ connectionString: config.databaseUrl, ssl: config.databaseSsl });
  }
  if (config.isProduction) {
    console.warn('[db] WARNING: DATABASE_URL is empty. Using the JSON test database - bookings will be LOST whenever the server restarts.');
  }
  return createJsonStore(config.dataFile);
}

async function migrate(db, log = console.log) {
  await db.init();
  log(`[db] Using ${db.kind === 'postgres' ? 'PostgreSQL' : `JSON test database (${config.dataFile})`}`);

  if (!(await db.getSetting('schedule'))) {
    await db.setSetting('schedule', seed.schedule);
    log('[db] Added default opening hours');
  }
  if ((await db.countInstructors()) === 0) {
    for (const i of seed.instructors) await db.createInstructor(i);
    log(`[db] Added ${seed.instructors.length} instructors`);
  }
  if ((await db.countPackages()) === 0) {
    for (const p of seed.packages) await db.createPackage(p);
    log(`[db] Added ${seed.packages.length} example packages (edit prices in Staff > Packages)`);
  }
  if ((await db.countStaff()) === 0) {
    let { email, name, password } = config.admin;
    if (!password) {
      if (config.isProduction) {
        log('[db] No staff account yet. Set ADMIN_EMAIL and ADMIN_PASSWORD and restart to create the first admin.');
        return;
      }
      email = email || 'admin@example.com';
      password = 'change-me-now';
      log(`[db] DEV ONLY: created staff login ${email} / ${password}  (set ADMIN_PASSWORD in .env to choose your own)`);
    } else if (password.length < 8) {
      log('[db] ADMIN_PASSWORD must be at least 8 characters - first admin NOT created.');
      return;
    }
    await db.createStaff({ email: email || 'admin@example.com', name, passwordHash: await hashPassword(password), role: 'admin' });
    log(`[db] Created admin account for ${email || 'admin@example.com'}`);
  }
}

module.exports = { createStore, migrate };
