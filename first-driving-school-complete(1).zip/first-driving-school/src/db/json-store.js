'use strict';
/**
 * JSON-file database for FREE LOCAL TESTING (used when DATABASE_URL is empty).
 * Same interface as postgres-store.js. Not for production: one process only,
 * and free hosts wipe the file on every restart.
 */
const fs = require('fs');
const path = require('path');

const ACTIVE = ['pending', 'confirmed'];
const clone = (v) => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
const nowIso = () => new Date().toISOString();

function createJsonStore(file) {
  let data = null;

  function load() {
    if (data) return data;
    if (fs.existsSync(file)) {
      data = JSON.parse(fs.readFileSync(file, 'utf8'));
    } else {
      data = {};
    }
    for (const t of ['staffUsers', 'instructors', 'packages', 'timeOff', 'bookings']) data[t] = data[t] || [];
    data.settings = data.settings || {};
    data.seq = data.seq || {};
    return data;
  }

  function save() {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
    fs.renameSync(tmp, file);
  }

  function nextId(table) {
    const d = load();
    d.seq[table] = (d.seq[table] || d[table].reduce((m, r) => Math.max(m, r.id), 0)) + 1;
    return d.seq[table];
  }

  const find = (table, id) => load()[table].find((r) => r.id === Number(id));

  function patchRow(table, id, patch, allowed) {
    const row = find(table, id);
    if (!row) return null;
    for (const k of allowed) if (patch[k] !== undefined) row[k] = clone(patch[k]);
    if ('updatedAt' in row) row.updatedAt = nowIso();
    save();
    return clone(row);
  }

  return {
    kind: 'json',
    async init() { load(); save(); },
    async close() {},

    // ---- staff ----
    async countStaff() { return load().staffUsers.length; },
    async getStaffByEmail(email) { return clone(load().staffUsers.find((u) => u.email === String(email).toLowerCase())) || null; },
    async getStaffById(id) { return clone(find('staffUsers', id)) || null; },
    async createStaff({ email, name, passwordHash, role }) {
      const row = { id: nextId('staffUsers'), email: email.toLowerCase(), name, passwordHash, role: role || 'staff', createdAt: nowIso() };
      load().staffUsers.push(row); save();
      return clone(row);
    },
    async updateStaffPassword(id, passwordHash) { return patchRow('staffUsers', id, { passwordHash }, ['passwordHash']); },

    // ---- instructors ----
    async countInstructors() { return load().instructors.length; },
    async listInstructors({ activeOnly } = {}) {
      return clone(load().instructors.filter((i) => !activeOnly || i.active).sort((a, b) => a.name.localeCompare(b.name)));
    },
    async getInstructor(id) { return clone(find('instructors', id)) || null; },
    async createInstructor(i) {
      const row = { id: nextId('instructors'), name: i.name, phone: i.phone || '', codes: i.codes || [], active: i.active !== false, notes: i.notes || '', createdAt: nowIso() };
      load().instructors.push(row); save();
      return clone(row);
    },
    async updateInstructor(id, patch) { return patchRow('instructors', id, patch, ['name', 'phone', 'codes', 'active', 'notes']); },
    async deleteInstructor(id) {
      const d = load();
      const before = d.instructors.length;
      d.instructors = d.instructors.filter((i) => i.id !== Number(id));
      d.timeOff = d.timeOff.filter((t) => t.instructorId !== Number(id));
      save();
      return d.instructors.length < before;
    },

    // ---- packages ----
    async countPackages() { return load().packages.length; },
    async listPackages({ activeOnly, code } = {}) {
      return clone(load().packages
        .filter((p) => (!activeOnly || p.active) && (!code || p.code === code))
        .sort((a, b) => a.code.localeCompare(b.code) || a.sortOrder - b.sortOrder || a.id - b.id));
    },
    async getPackage(id) { return clone(find('packages', id)) || null; },
    async createPackage(p) {
      const row = { id: nextId('packages'), code: p.code, name: p.name, description: p.description || '', lessons: p.lessons || 1, durationMin: p.durationMin || 60, price: Number(p.price) || 0, active: p.active !== false, sortOrder: p.sortOrder || 0 };
      load().packages.push(row); save();
      return clone(row);
    },
    async updatePackage(id, patch) { return patchRow('packages', id, patch, ['code', 'name', 'description', 'lessons', 'durationMin', 'price', 'active', 'sortOrder']); },

    // ---- settings ----
    async getSetting(key) { return clone(load().settings[key]) ?? null; },
    async setSetting(key, value) { load().settings[key] = clone(value); save(); return clone(value); },

    // ---- time off ----
    async listTimeOff({ from, to } = {}) {
      return clone(load().timeOff
        .filter((t) => (!from || t.date >= from) && (!to || t.date <= to))
        .sort((a, b) => a.date.localeCompare(b.date) || a.id - b.id));
    },
    async createTimeOff(t) {
      const row = { id: nextId('timeOff'), instructorId: t.instructorId ?? null, date: t.date, startTime: t.startTime || null, endTime: t.endTime || null, reason: t.reason || '', createdAt: nowIso() };
      load().timeOff.push(row); save();
      return clone(row);
    },
    async deleteTimeOff(id) {
      const d = load();
      const before = d.timeOff.length;
      d.timeOff = d.timeOff.filter((t) => t.id !== Number(id));
      save();
      return d.timeOff.length < before;
    },

    // ---- bookings ----
    async listBookings({ from, to, date, status, instructorId, q, limit } = {}) {
      const statuses = status ? [].concat(status) : null;
      const needle = q ? String(q).toLowerCase() : null;
      let rows = load().bookings.filter((b) =>
        (!date || b.lessonDate === date) &&
        (!from || b.lessonDate >= from) &&
        (!to || b.lessonDate <= to) &&
        (!statuses || statuses.includes(b.status)) &&
        (!instructorId || b.instructorId === Number(instructorId)) &&
        (!needle || [b.reference, b.customerName, b.customerPhone, b.customerEmail].some((f) => String(f || '').toLowerCase().includes(needle))));
      rows.sort((a, b) => a.lessonDate.localeCompare(b.lessonDate) || a.startTime.localeCompare(b.startTime) || a.id - b.id);
      if (limit) rows = rows.slice(0, limit);
      return clone(rows);
    },
    async getBookingById(id) { return clone(find('bookings', id)) || null; },
    async getBookingByReference(ref) { return clone(load().bookings.find((b) => b.reference === String(ref).toUpperCase())) || null; },
    async createBooking(b) {
      const d = load();
      if (d.bookings.some((x) => x.reference === b.reference)) {
        const e = new Error('duplicate reference'); e.code = 'DUPLICATE'; throw e;
      }
      if (b.instructorId && ACTIVE.includes(b.status || 'pending') && d.bookings.some((x) =>
        x.instructorId === b.instructorId && x.lessonDate === b.lessonDate && x.startTime === b.startTime && ACTIVE.includes(x.status))) {
        const e = new Error('slot taken'); e.code = 'DUPLICATE'; throw e;
      }
      const ts = nowIso();
      const row = {
        id: nextId('bookings'), reference: b.reference, licenseCode: b.licenseCode, packageId: b.packageId ?? null,
        packageName: b.packageName, price: Number(b.price) || 0, lessonDate: b.lessonDate, startTime: b.startTime,
        durationMin: b.durationMin, instructorId: b.instructorId ?? null, customerName: b.customerName,
        customerPhone: b.customerPhone, customerEmail: b.customerEmail || '', pickupLocation: b.pickupLocation || '',
        notes: b.notes || '', status: b.status || 'pending', staffNotes: b.staffNotes || '', createdAt: ts, updatedAt: ts,
      };
      d.bookings.push(row); save();
      return clone(row);
    },
    async updateBooking(id, patch) {
      return patchRow('bookings', id, patch, ['status', 'instructorId', 'lessonDate', 'startTime', 'durationMin', 'staffNotes', 'customerName', 'customerPhone', 'customerEmail', 'pickupLocation', 'notes']);
    },
    async countBookingsForInstructor(id) { return load().bookings.filter((b) => b.instructorId === Number(id)).length; },
  };
}

module.exports = { createJsonStore };
