'use strict';
/**
 * Starter data inserted the first time the database is empty.
 * PRICES ARE EXAMPLES - change them in the Staff dashboard > Packages.
 */
const instructors = [
  { name: 'Andre', phone: '', codes: ['B', 'A1'], notes: 'Owner. Car and motorcycle.' },
  { name: 'Bee', phone: '', codes: ['B', 'A1'], notes: 'Car and motorcycle.' },
  { name: 'Boyboy', phone: '', codes: ['B'], notes: 'Car.' },
  { name: 'Emanuel', phone: '', codes: ['C1', 'C1E'], notes: 'Truck and trailer.' },
];

const p = (code, name, description, lessons, durationMin, price, sortOrder) =>
  ({ code, name, description, lessons, durationMin, price, sortOrder, active: true });

const packages = [
  p('B', 'Single lesson', 'One 60-minute lesson in our dual-control car.', 1, 60, 350, 1),
  p('B', '5-lesson package', 'Five 60-minute lessons. Book the first one now; we plan the rest with you.', 5, 60, 1650, 2),
  p('B', '10-lesson package', 'Ten 60-minute lessons from first drive to test-ready.', 10, 60, 3100, 3),
  p('B', 'Test preparation', 'A 2-hour warm-up and use of our car for your driving test.', 1, 120, 900, 4),
  p('A1', 'Single lesson', 'One 60-minute motorcycle lesson, bike and helmet included.', 1, 60, 350, 1),
  p('A1', '5-lesson package', 'Five 60-minute motorcycle lessons.', 5, 60, 1650, 2),
  p('A1', 'Test preparation', 'A 2-hour warm-up and use of our motorcycle for your test.', 1, 120, 900, 3),
  p('C1', 'Single lesson', 'One 60-minute lesson in our medium truck.', 1, 60, 650, 1),
  p('C1', '5-lesson package', 'Five 60-minute truck lessons.', 5, 60, 3000, 2),
  p('C1', 'Test preparation', 'A 2-hour warm-up and use of our truck for your test.', 1, 120, 1500, 3),
  p('C1E', 'Single lesson', 'One 60-minute lesson with truck and trailer.', 1, 60, 750, 1),
  p('C1E', '5-lesson package', 'Five 60-minute truck-and-trailer lessons.', 5, 60, 3500, 2),
  p('C1E', 'Test preparation', 'A 2-hour warm-up and use of our truck and trailer for your test.', 1, 120, 1700, 3),
];

/** Weekly opening hours. Keys are weekdays: 0 = Sunday ... 6 = Saturday. null = closed. */
const schedule = {
  slotMinutes: 60,
  bookingWindowDays: 30,
  minNoticeHours: 12,
  hours: {
    0: null,
    1: { open: '07:00', close: '17:00' },
    2: { open: '07:00', close: '17:00' },
    3: { open: '07:00', close: '17:00' },
    4: { open: '07:00', close: '17:00' },
    5: { open: '07:00', close: '17:00' },
    6: { open: '08:00', close: '13:00' },
  },
};

module.exports = { instructors, packages, schedule };
