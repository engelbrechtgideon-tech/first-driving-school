'use strict';
/** Staff API: login, bookings, instructors, schedule, time off, packages, stats. All except login need a token. */
const { HttpError, rateLimiter } = require('../http');
const { hashPassword, verifyPassword, signToken, requireStaff, requireAdmin } = require('../auth');
const LICENSE_CODES = require('../license-codes');
const T = require('../services/time');
const config = require('../config');
const { loadContext, computeDay } = require('../services/availability');
const { createBooking, updateBooking, STATUSES } = require('../services/bookings');

const loginLimiter = rateLimiter({ windowMs: 15 * 60 * 1000, max: 10, message: 'Too many login attempts. Wait 15 minutes and try again.' });
const CODES = LICENSE_CODES.map((c) => c.code);
const str = (v, max) => String(v ?? '').trim().slice(0, max);
const toId = (v) => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw new HttpError(400, 'Invalid id.'); return n; };

function cleanInstructor(body, partial) {
  const out = {};
  const errors = {};
  if (!partial || body.name !== undefined) { out.name = str(body.name, 60); if (out.name.length < 2) errors.name = 'Enter a name.'; }
  if (body.phone !== undefined) out.phone = str(body.phone, 25);
  if (body.notes !== undefined) out.notes = str(body.notes, 300);
  if (body.active !== undefined) out.active = Boolean(body.active);
  if (!partial || body.codes !== undefined) {
    out.codes = Array.isArray(body.codes) ? [...new Set(body.codes.map((c) => String(c).toUpperCase()))].filter((c) => CODES.includes(c)) : [];
    if (!out.codes.length) errors.codes = 'Choose at least one licence code.';
  }
  if (Object.keys(errors).length) throw new HttpError(422, 'Please check the highlighted fields.', errors);
  return out;
}

function cleanPackage(body, partial) {
  const out = {};
  const errors = {};
  if (!partial || body.code !== undefined) { out.code = str(body.code, 5).toUpperCase(); if (!CODES.includes(out.code)) errors.code = 'Choose a licence code.'; }
  if (!partial || body.name !== undefined) { out.name = str(body.name, 60); if (out.name.length < 2) errors.name = 'Enter a name.'; }
  if (body.description !== undefined) out.description = str(body.description, 300);
  for (const [k, min, max] of [['lessons', 1, 100], ['durationMin', 15, 480], ['sortOrder', 0, 999]]) {
    if (body[k] !== undefined || (!partial && k !== 'sortOrder')) {
      const n = Number(body[k]);
      if (!Number.isInteger(n) || n < min || n > max) errors[k] = `Enter a whole number from ${min} to ${max}.`; else out[k] = n;
    }
  }
  if (!partial || body.price !== undefined) {
    const n = Number(body.price);
    if (!Number.isFinite(n) || n < 0 || n > 1_000_000) errors.price = 'Enter a price in N$.'; else out.price = Math.round(n * 100) / 100;
  }
  if (body.active !== undefined) out.active = Boolean(body.active);
  if (Object.keys(errors).length) throw new HttpError(422, 'Please check the highlighted fields.', errors);
  return out;
}

function cleanSchedule(body, current) {
  const errors = {};
  const out = { ...current };
  for (const [k, min, max] of [['slotMinutes', 15, 240], ['bookingWindowDays', 1, 365], ['minNoticeHours', 0, 168]]) {
    if (body[k] !== undefined) {
      const n = Number(body[k]);
      if (!Number.isInteger(n) || n < min || n > max) errors[k] = `Enter a whole number from ${min} to ${max}.`; else out[k] = n;
    }
  }
  if (body.hours !== undefined) {
    out.hours = {};
    for (let d = 0; d < 7; d += 1) {
      const h = body.hours[d] ?? body.hours[String(d)];
      if (!h) { out.hours[d] = null; continue; }
      if (!T.isValidTime(h.open) || !T.isValidTime(h.close) || T.toMin(h.close) <= T.toMin(h.open)) errors[`hours.${d}`] = 'Closing time must be after opening time.';
      else out.hours[d] = { open: h.open, close: h.close };
    }
  }
  if (Object.keys(errors).length) throw new HttpError(422, 'Please check the highlighted fields.', errors);
  return out;
}

module.exports = function registerStaffRoutes(router) {
  // ---------- auth ----------
  router.post('/api/auth/login', loginLimiter, async (ctx) => {
    const email = str(ctx.body.email, 120).toLowerCase();
    const user = email ? await ctx.db.getStaffByEmail(email) : null;
    const ok = user && (await verifyPassword(ctx.body.password || '', user.passwordHash));
    if (!ok) throw new HttpError(401, 'Email or password is incorrect.');
    return { token: signToken({ sub: user.id, role: user.role }), user: { id: user.id, email: user.email, name: user.name, role: user.role } };
  });

  router.get('/api/auth/me', requireStaff, async (ctx) => ({ user: ctx.user }));

  router.post('/api/auth/change-password', requireStaff, async (ctx) => {
    const user = await ctx.db.getStaffById(ctx.user.id);
    if (!(await verifyPassword(ctx.body.currentPassword || '', user.passwordHash))) throw new HttpError(422, 'Current password is incorrect.', { currentPassword: 'Current password is incorrect.' });
    const next = String(ctx.body.newPassword || '');
    if (next.length < 8) throw new HttpError(422, 'Use at least 8 characters.', { newPassword: 'Use at least 8 characters.' });
    await ctx.db.updateStaffPassword(user.id, await hashPassword(next));
    return { ok: true };
  });

  router.post('/api/staff/users', requireStaff, requireAdmin, async (ctx) => {
    const email = str(ctx.body.email, 120).toLowerCase();
    const name = str(ctx.body.name, 60);
    const password = String(ctx.body.password || '');
    const errors = {};
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = 'Enter a valid email.';
    if (name.length < 2) errors.name = 'Enter a name.';
    if (password.length < 8) errors.password = 'Use at least 8 characters.';
    if (Object.keys(errors).length) throw new HttpError(422, 'Please check the highlighted fields.', errors);
    if (await ctx.db.getStaffByEmail(email)) throw new HttpError(409, 'A staff account with this email already exists.');
    const role = ctx.body.role === 'admin' ? 'admin' : 'staff';
    const u = await ctx.db.createStaff({ email, name, passwordHash: await hashPassword(password), role });
    ctx.status = 201;
    return { user: { id: u.id, email: u.email, name: u.name, role: u.role } };
  });

  // ---------- dashboard ----------
  router.get('/api/staff/stats', requireStaff, async (ctx) => {
    const today = T.nowIn(config.timezone).date;
    const monthStart = `${today.slice(0, 7)}-01`;
    const [upcoming, month] = await Promise.all([
      ctx.db.listBookings({ from: today, to: T.addDays(today, 30), status: ['pending', 'confirmed'] }),
      ctx.db.listBookings({ from: monthStart, to: T.addDays(monthStart, 31) }),
    ]);
    const inMonth = month.filter((b) => b.lessonDate.slice(0, 7) === today.slice(0, 7));
    return {
      today,
      todayCount: upcoming.filter((b) => b.lessonDate === today).length,
      pendingCount: upcoming.filter((b) => b.status === 'pending').length,
      upcomingCount: upcoming.length,
      monthBookedValue: inMonth.filter((b) => ['confirmed', 'completed'].includes(b.status)).reduce((s, b) => s + Number(b.price || 0), 0),
      monthCount: inMonth.filter((b) => b.status !== 'cancelled').length,
    };
  });

  // ---------- bookings ----------
  router.get('/api/staff/bookings', requireStaff, async (ctx) => {
    const qp = ctx.query;
    const filters = {};
    for (const k of ['from', 'to', 'date']) if (T.isValidDate(qp.get(k))) filters[k] = qp.get(k);
    if (qp.get('status')) filters.status = qp.get('status').split(',').filter((s) => STATUSES.includes(s));
    if (qp.get('instructorId')) filters.instructorId = toId(qp.get('instructorId'));
    if (qp.get('q')) filters.q = str(qp.get('q'), 60);
    filters.limit = Math.min(parseInt(qp.get('limit'), 10) || 500, 2000);
    return { bookings: await ctx.db.listBookings(filters) };
  });

  router.post('/api/staff/bookings', requireStaff, async (ctx) => {
    ctx.status = 201;
    return { booking: await createBooking(ctx.db, ctx.body, { staff: true }) };
  });

  router.get('/api/staff/bookings/:id', requireStaff, async (ctx) => {
    const b = await ctx.db.getBookingById(toId(ctx.params.id));
    if (!b) throw new HttpError(404, 'Booking not found.');
    return { booking: b };
  });

  router.patch('/api/staff/bookings/:id', requireStaff, async (ctx) => ({ booking: await updateBooking(ctx.db, toId(ctx.params.id), ctx.body) }));

  // Free times for staff (ignores minimum notice): /api/staff/availability?code=B&date=...&durationMin=60&excludeBookingId=
  router.get('/api/staff/availability', requireStaff, async (ctx) => {
    const code = String(ctx.query.get('code') || '').toUpperCase();
    const date = ctx.query.get('date');
    if (!CODES.includes(code) || !T.isValidDate(date)) throw new HttpError(400, 'Code and date are required.');
    const durationMin = Math.min(Math.max(parseInt(ctx.query.get('durationMin'), 10) || 60, 15), 480);
    const exclude = ctx.query.get('excludeBookingId') ? toId(ctx.query.get('excludeBookingId')) : null;
    const lc = await loadContext(ctx.db, date, date);
    return computeDay(lc, { date, code, durationMin, staff: true, excludeBookingId: exclude });
  });

  // ---------- instructors ----------
  router.get('/api/staff/instructors', requireStaff, async (ctx) => ({ instructors: await ctx.db.listInstructors() }));

  router.post('/api/staff/instructors', requireStaff, async (ctx) => {
    ctx.status = 201;
    return { instructor: await ctx.db.createInstructor(cleanInstructor(ctx.body, false)) };
  });

  router.patch('/api/staff/instructors/:id', requireStaff, async (ctx) => {
    const i = await ctx.db.updateInstructor(toId(ctx.params.id), cleanInstructor(ctx.body, true));
    if (!i) throw new HttpError(404, 'Instructor not found.');
    return { instructor: i };
  });

  // Instructors with lesson history are deactivated instead of deleted, so old bookings keep their name.
  router.delete('/api/staff/instructors/:id', requireStaff, async (ctx) => {
    const id = toId(ctx.params.id);
    if ((await ctx.db.countBookingsForInstructor(id)) > 0) {
      await ctx.db.updateInstructor(id, { active: false });
      return { deactivated: true };
    }
    if (!(await ctx.db.deleteInstructor(id))) throw new HttpError(404, 'Instructor not found.');
    return { deleted: true };
  });

  // ---------- schedule ----------
  router.get('/api/staff/schedule', requireStaff, async (ctx) => ({ schedule: await ctx.db.getSetting('schedule') }));

  router.put('/api/staff/schedule', requireStaff, async (ctx) => {
    const current = await ctx.db.getSetting('schedule');
    return { schedule: await ctx.db.setSetting('schedule', cleanSchedule(ctx.body, current)) };
  });

  router.get('/api/staff/time-off', requireStaff, async (ctx) => {
    const from = T.isValidDate(ctx.query.get('from')) ? ctx.query.get('from') : T.nowIn(config.timezone).date;
    const to = T.isValidDate(ctx.query.get('to')) ? ctx.query.get('to') : undefined;
    return { timeOff: await ctx.db.listTimeOff({ from, to }) };
  });

  router.post('/api/staff/time-off', requireStaff, async (ctx) => {
    const b = ctx.body;
    const errors = {};
    if (!T.isValidDate(b.date)) errors.date = 'Choose a date.';
    const whole = !b.startTime && !b.endTime;
    if (!whole && (!T.isValidTime(b.startTime) || !T.isValidTime(b.endTime) || T.toMin(b.endTime) <= T.toMin(b.startTime))) errors.endTime = 'End time must be after start time.';
    let instructorId = null;
    if (b.instructorId) {
      instructorId = toId(b.instructorId);
      if (!(await ctx.db.getInstructor(instructorId))) errors.instructorId = 'Unknown instructor.';
    }
    if (Object.keys(errors).length) throw new HttpError(422, 'Please check the highlighted fields.', errors);
    ctx.status = 201;
    return { timeOff: await ctx.db.createTimeOff({ instructorId, date: b.date, startTime: whole ? null : b.startTime, endTime: whole ? null : b.endTime, reason: str(b.reason, 120) }) };
  });

  router.delete('/api/staff/time-off/:id', requireStaff, async (ctx) => {
    if (!(await ctx.db.deleteTimeOff(toId(ctx.params.id)))) throw new HttpError(404, 'Not found.');
    return { deleted: true };
  });

  // ---------- packages ----------
  router.get('/api/staff/packages', requireStaff, async (ctx) => ({ packages: await ctx.db.listPackages() }));

  router.post('/api/staff/packages', requireStaff, async (ctx) => {
    ctx.status = 201;
    return { package: await ctx.db.createPackage(cleanPackage(ctx.body, false)) };
  });

  router.patch('/api/staff/packages/:id', requireStaff, async (ctx) => {
    const p = await ctx.db.updatePackage(toId(ctx.params.id), cleanPackage(ctx.body, true));
    if (!p) throw new HttpError(404, 'Package not found.');
    return { package: p };
  });
};
