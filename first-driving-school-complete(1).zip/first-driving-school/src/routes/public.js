'use strict';
/** Customer-facing API: packages, availability, create booking, look up booking. */
const { HttpError, rateLimiter } = require('../http');
const LICENSE_CODES = require('../license-codes');
const T = require('../services/time');
const config = require('../config');
const { loadContext, computeDay } = require('../services/availability');
const { createBooking } = require('../services/bookings');

const bookingLimiter = rateLimiter({ windowMs: 60 * 60 * 1000, max: 20, message: 'Too many bookings from this device. Please call or WhatsApp us.' });

/** What a customer may see about a booking. */
function publicBooking(b, instructor) {
  return {
    reference: b.reference, licenseCode: b.licenseCode, packageName: b.packageName, price: b.price,
    lessonDate: b.lessonDate, startTime: b.startTime, durationMin: b.durationMin, status: b.status,
    customerName: b.customerName, pickupLocation: b.pickupLocation,
    instructorName: instructor ? instructor.name : null, createdAt: b.createdAt,
  };
}

async function resolvePackage(db, query) {
  const code = String(query.get('code') || '').toUpperCase();
  if (!LICENSE_CODES.some((c) => c.code === code)) throw new HttpError(400, 'Unknown licence code.');
  const pkg = await db.getPackage(Number(query.get('packageId')));
  if (!pkg || !pkg.active || pkg.code !== code) throw new HttpError(400, 'Unknown package for this licence code.');
  return { code, pkg };
}

module.exports = function registerPublicRoutes(router) {
  router.get('/api/health', async (ctx) => ({ ok: true, database: ctx.db.kind, time: new Date().toISOString() }));

  router.get('/api/catalog', async (ctx) => {
    const [packages, schedule, instructors] = await Promise.all([
      ctx.db.listPackages({ activeOnly: true }),
      ctx.db.getSetting('schedule'),
      ctx.db.listInstructors({ activeOnly: true }),
    ]);
    const taught = new Set(instructors.flatMap((i) => i.codes));
    return {
      licenseCodes: LICENSE_CODES.map((c) => ({ ...c, available: taught.has(c.code) && packages.some((p) => p.code === c.code) })),
      packages,
      schedule: { hours: schedule.hours, bookingWindowDays: schedule.bookingWindowDays, minNoticeHours: schedule.minNoticeHours },
      today: T.nowIn(config.timezone).date,
      timezone: config.timezone,
    };
  });

  // Day-by-day overview for the date picker: /api/availability/days?code=B&packageId=1&from=2026-10-01&days=14
  router.get('/api/availability/days', async (ctx) => {
    const { code, pkg } = await resolvePackage(ctx.db, ctx.query);
    const today = T.nowIn(config.timezone).date;
    const from = T.isValidDate(ctx.query.get('from')) ? ctx.query.get('from') : today;
    const days = Math.min(Math.max(parseInt(ctx.query.get('days'), 10) || 14, 1), 42);
    const to = T.addDays(from, days - 1);
    const lc = await loadContext(ctx.db, from, to);
    const out = [];
    for (let d = from; d <= to; d = T.addDays(d, 1)) {
      const day = computeDay(lc, { date: d, code, durationMin: pkg.durationMin });
      out.push({ date: d, open: day.open, reason: day.reason, freeSlots: day.slots.filter((s) => s.available).length });
    }
    return { code, packageId: pkg.id, days: out };
  });

  // Times for one day: /api/availability?code=B&packageId=1&date=2026-10-01
  router.get('/api/availability', async (ctx) => {
    const { code, pkg } = await resolvePackage(ctx.db, ctx.query);
    const date = ctx.query.get('date');
    if (!T.isValidDate(date)) throw new HttpError(400, 'Invalid date.');
    const lc = await loadContext(ctx.db, date, date);
    const day = computeDay(lc, { date, code, durationMin: pkg.durationMin });
    return { date, open: day.open, reason: day.reason, durationMin: pkg.durationMin, slots: day.slots.map((s) => ({ time: s.time, available: s.available })) };
  });

  router.post('/api/bookings', bookingLimiter, async (ctx) => {
    const booking = await createBooking(ctx.db, ctx.body);
    const instructor = booking.instructorId ? await ctx.db.getInstructor(booking.instructorId) : null;
    ctx.status = 201;
    return { booking: publicBooking(booking, instructor) };
  });

  // Look up a booking: /api/bookings/FDS-ABC123?phone=0812345678 (last 4 digits must match)
  router.get('/api/bookings/:reference', async (ctx) => {
    const b = await ctx.db.getBookingByReference(ctx.params.reference);
    const phone = String(ctx.query.get('phone') || '').replace(/\D/g, '');
    if (!b || phone.length < 4 || !b.customerPhone.replace(/\D/g, '').endsWith(phone.slice(-4))) {
      throw new HttpError(404, 'No booking found with that reference and phone number.');
    }
    const instructor = b.instructorId ? await ctx.db.getInstructor(b.instructorId) : null;
    return { booking: publicBooking(b, instructor) };
  });
};
