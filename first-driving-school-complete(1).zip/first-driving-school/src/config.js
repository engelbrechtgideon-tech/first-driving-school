'use strict';
/**
 * Loads settings from environment variables (and from .env when present).
 * No secrets are hard-coded here - see .env.example.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const envFile = path.join(ROOT, '.env');
if (fs.existsSync(envFile) && typeof process.loadEnvFile === 'function') {
  process.loadEnvFile(envFile);
}

const env = process.env;
const isProduction = env.NODE_ENV === 'production';

let jwtSecret = (env.JWT_SECRET || '').trim();
if (!jwtSecret) {
  if (isProduction) {
    throw new Error('JWT_SECRET is not set. It is required when NODE_ENV=production (see .env.example).');
  }
  jwtSecret = crypto.randomBytes(32).toString('hex');
  console.warn('[config] JWT_SECRET not set - using a temporary random secret (staff must log in again after each restart).');
}
if (isProduction && jwtSecret.length < 32) {
  throw new Error('JWT_SECRET must be at least 32 characters long in production.');
}

const bool = (v, dflt) => (v === undefined || v === '' ? dflt : ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase()));

module.exports = {
  ROOT,
  PUBLIC_DIR: path.join(ROOT, 'public'),
  isProduction,
  port: parseInt(env.PORT, 10) || 3000,
  databaseUrl: (env.DATABASE_URL || '').trim(),
  databaseSsl: bool(env.DATABASE_SSL, true),
  dataFile: path.resolve(ROOT, env.DATA_FILE || './data/dev-db.json'),
  autoMigrate: bool(env.AUTO_MIGRATE, true),
  jwtSecret,
  sessionHours: parseInt(env.SESSION_HOURS, 10) || 12,
  admin: {
    email: (env.ADMIN_EMAIL || '').trim().toLowerCase(),
    name: (env.ADMIN_NAME || 'Administrator').trim(),
    password: env.ADMIN_PASSWORD || '',
  },
  allowedOrigins: (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim().replace(/\/$/, '')).filter(Boolean),
  trustProxy: bool(env.TRUST_PROXY, isProduction),
  timezone: env.TIMEZONE || 'Africa/Windhoek',
};
