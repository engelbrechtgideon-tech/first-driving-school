'use strict';
/** Licence codes offered by First Driving School. Shown on the booking page. */
module.exports = [
  { code: 'B', title: 'Code B', vehicle: 'Light motor vehicle', detail: 'Cars and bakkies up to 3,500 kg' },
  { code: 'A1', title: 'Code A1', vehicle: 'Motorcycle', detail: 'Light motorcycles up to 125 cc' },
  { code: 'C1', title: 'Code C1', vehicle: 'Medium truck', detail: 'Trucks from 3,500 kg to 16,000 kg' },
  { code: 'C1E', title: 'Code C1E', vehicle: 'Truck with trailer', detail: 'C1 truck towing a trailer over 750 kg' },
];
