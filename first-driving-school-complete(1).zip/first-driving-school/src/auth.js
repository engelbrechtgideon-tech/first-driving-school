'use strict';
/** Password hashing (scrypt) and signed session tokens (JWT, HS256) using only Node built-ins. */
const crypto = require('crypto');
const { promisify } = require('util');
const config = require('./config');
const { HttpError } = require('./http');

const scrypt = promisify(crypto.scrypt);
const KEYLEN = 64;

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = await scrypt(String(password), salt, KEYLEN);
  return `scrypt$${salt}$${hash.toString('hex')}`;
}

async function verifyPassword(password, stored) {
  if (!stored || !stored.startsWith('scrypt$')) return false;
  const [, salt, hex] = stored.split('$');
  const expected = Buffer.from(hex, 'hex');
  const actual = await scrypt(String(password), salt, expected.length);
  return crypto.timingSafeEqual(expected, actual);
}

const b64url = (buf) => Buffer.from(buf).toString('base64url');

function signToken(payload) {
  const header = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const now = Math.floor(Date.now() / 1000);
  const body = b64url(JSON.stringify({ ...payload, iat: now, exp: now + config.sessionHours * 3600 }));
  const sig = crypto.createHmac('sha256', config.jwtSecret).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}

function verifyToken(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) return null;
  const [header, body, sig] = parts;
  const expected = crypto.createHmac('sha256', config.jwtSecret).update(`${header}.${body}`).digest();
  const given = Buffer.from(sig, 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

/** Route guard: attaches ctx.user or throws 401. */
async function requireStaff(ctx) {
  const header = ctx.req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  const payload = verifyToken(token);
  if (!payload) throw new HttpError(401, 'Your session has ended. Please log in again.');
  const user = await ctx.db.getStaffById(payload.sub);
  if (!user) throw new HttpError(401, 'Your session has ended. Please log in again.');
  ctx.user = { id: user.id, email: user.email, name: user.name, role: user.role };
}

function requireAdmin(ctx) {
  if (!ctx.user || ctx.user.role !== 'admin') throw new HttpError(403, 'Only an admin can do this.');
}

module.exports = { hashPassword, verifyPassword, signToken, verifyToken, requireStaff, requireAdmin };
